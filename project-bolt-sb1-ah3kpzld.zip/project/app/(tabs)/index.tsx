import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Bell, ArrowRight, TrendingUp, Shield, Award } from 'lucide-react-native';
import StatsCard from '@/components/StatsCard';
import FeaturedDonation from '@/components/FeaturedDonation';

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Welcome back,</Text>
            <Text style={styles.username}>Sarah</Text>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <Bell size={24} color={Colors.neutral[700]} />
            <View style={styles.notificationBadge}>
              <Text style={styles.notificationCount}>3</Text>
            </View>
          </TouchableOpacity>
        </View>
        
        <View style={styles.impactSection}>
          <Text style={styles.sectionTitle}>Your Impact</Text>
          <View style={styles.statsRow}>
            <StatsCard 
              icon={<TrendingUp size={20} color={Colors.primary[500]} />}
              title="Donations"
              value="12"
              subtitle="This month"
              color={Colors.primary[50]}
            />
            <StatsCard 
              icon={<Shield size={20} color={Colors.secondary[500]} />}
              title="Verified"
              value="8"
              subtitle="By pharmacists"
              color={Colors.secondary[50]}
            />
          </View>
        </View>

        <View style={styles.verificationSection}>
          <View style={styles.verificationBox}>
            <Image
              source={{ uri: "https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" }}
              style={styles.pharmacistImage}
            />
            <View style={styles.verificationContent}>
              <View style={styles.verificationBadge}>
                <Award size={12} color={Colors.white} />
                <Text style={styles.verificationBadgeText}>VERIFIED PROCESS</Text>
              </View>
              <Text style={styles.verificationTitle}>Pharmacist Verification</Text>
              <Text style={styles.verificationDescription}>
                A licensed pharmacist will verify each donation before it's available to the public
              </Text>
              <TouchableOpacity style={styles.learnMoreButton}>
                <Text style={styles.learnMoreText}>Learn more</Text>
                <ArrowRight size={16} color={Colors.primary[600]} />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={styles.featuredSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Featured Donations</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See all</Text>
            </TouchableOpacity>
          </View>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.featuredScrollContent}
          >
            <FeaturedDonation 
              name="Amoxicillin"
              type="Antibiotic"
              distance="2.3 miles away"
              expiryDate="Jan 2025"
              imageUrl="https://images.pexels.com/photos/139398/himalayas-mountains-nepal-hill-139398.jpeg?auto=compress&cs=tinysrgb&w=800"
            />
            <FeaturedDonation 
              name="Metformin"
              type="Diabetes"
              distance="0.8 miles away"
              expiryDate="Dec 2024"
              imageUrl="https://images.pexels.com/photos/208512/pexels-photo-208512.jpeg?auto=compress&cs=tinysrgb&w=800"
            />
            <FeaturedDonation 
              name="Lisinopril"
              type="Blood Pressure"
              distance="3.5 miles away"
              expiryDate="Mar 2025"
              imageUrl="https://images.pexels.com/photos/669621/pexels-photo-669621.jpeg?auto=compress&cs=tinysrgb&w=800"
            />
          </ScrollView>
        </View>

        <View style={styles.spacer} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.md,
  },
  greeting: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[500],
  },
  username: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  notificationButton: {
    width: 46,
    height: 46,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  notificationBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: Colors.accent[500],
    width: 16,
    height: 16,
    borderRadius: Layout.borderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: Colors.white,
  },
  notificationCount: {
    fontFamily: 'Inter-Medium',
    fontSize: 10,
    color: Colors.white,
  },
  impactSection: {
    paddingHorizontal: Layout.spacing.md,
    marginTop: Layout.spacing.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.sm,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: Layout.spacing.md,
  },
  verificationSection: {
    paddingHorizontal: Layout.spacing.md,
    marginTop: Layout.spacing.xl,
  },
  verificationBox: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 2,
  },
  pharmacistImage: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
  },
  verificationContent: {
    padding: Layout.spacing.md,
  },
  verificationBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[500],
    alignSelf: 'flex-start',
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: 4,
    borderRadius: Layout.borderRadius.full,
    marginBottom: Layout.spacing.sm,
  },
  verificationBadgeText: {
    fontFamily: 'Inter-Medium',
    fontSize: 10,
    color: Colors.white,
    marginLeft: 4,
  },
  verificationTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  verificationDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 21,
    marginBottom: Layout.spacing.sm,
  },
  learnMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  learnMoreText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.primary[600],
    marginRight: Layout.spacing.xs,
  },
  featuredSection: {
    paddingHorizontal: Layout.spacing.md,
    marginTop: Layout.spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  seeAllText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[500],
  },
  featuredScrollContent: {
    paddingRight: Layout.spacing.md,
  },
  spacer: {
    height: 100,
  },
});