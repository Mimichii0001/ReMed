import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  ScrollView 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Settings, LogOut, Edit2, ChevronRight, MapPin, Clock, Package } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function ProfileScreen() {
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.headerActions}>
            <TouchableOpacity>
              <Settings size={24} color={Colors.neutral[700]} />
            </TouchableOpacity>
            <TouchableOpacity>
              <LogOut size={24} color={Colors.neutral[700]} />
            </TouchableOpacity>
          </View>
          
          <Animated.View 
            style={styles.profileSection}
            entering={FadeInDown.delay(100).springify()}
          >
            <Image
              source={{ uri: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" }}
              style={styles.profileImage}
            />
            <View style={styles.profileImageEditButton}>
              <Edit2 size={16} color={Colors.white} />
            </View>
            <Text style={styles.userName}>Sarah Johnson</Text>
            <Text style={styles.userLocation}>
              <MapPin size={14} color={Colors.neutral[500]} style={{ marginRight: 4 }} />
              San Francisco, CA
            </Text>
            <View style={styles.userStats}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>12</Text>
                <Text style={styles.statLabel}>Donations</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>8</Text>
                <Text style={styles.statLabel}>Verified</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>4</Text>
                <Text style={styles.statLabel}>Pending</Text>
              </View>
            </View>
          </Animated.View>
        </View>

        <Animated.View 
          style={styles.sectionContainer}
          entering={FadeInDown.delay(200).springify()}
        >
          <Text style={styles.sectionTitle}>My Donations</Text>
          <View style={styles.donationCards}>
            <TouchableOpacity style={styles.donationCard}>
              <View style={[styles.donationStatusBadge, { backgroundColor: Colors.success[500] }]}>
                <Text style={styles.donationStatusText}>Verified</Text>
              </View>
              <View style={styles.donationCardContent}>
                <View style={styles.donationCardHeader}>
                  <Text style={styles.donationCardTitle}>Amoxicillin 500mg</Text>
                  <Text style={styles.donationCardDate}>
                    <Clock size={14} color={Colors.neutral[400]} style={{ marginRight: 2 }} />
                    Donated 3 days ago
                  </Text>
                </View>
                <View style={styles.donationCardDetails}>
                  <View style={styles.donationCardDetail}>
                    <Package size={14} color={Colors.neutral[500]} />
                    <Text style={styles.donationCardDetailText}>30 tablets</Text>
                  </View>
                  <View style={styles.donationCardDetail}>
                    <Clock size={14} color={Colors.neutral[500]} />
                    <Text style={styles.donationCardDetailText}>Expires Jan 2025</Text>
                  </View>
                </View>
                <View style={styles.donationCardFooter}>
                  <Text style={styles.verifiedText}>
                    Verified by Dr. Michael C.
                  </Text>
                  <ChevronRight size={20} color={Colors.neutral[400]} />
                </View>
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.donationCard}>
              <View style={[styles.donationStatusBadge, { backgroundColor: Colors.warning[500] }]}>
                <Text style={styles.donationStatusText}>Pending</Text>
              </View>
              <View style={styles.donationCardContent}>
                <View style={styles.donationCardHeader}>
                  <Text style={styles.donationCardTitle}>Metformin 1000mg</Text>
                  <Text style={styles.donationCardDate}>
                    <Clock size={14} color={Colors.neutral[400]} style={{ marginRight: 2 }} />
                    Donated 1 day ago
                  </Text>
                </View>
                <View style={styles.donationCardDetails}>
                  <View style={styles.donationCardDetail}>
                    <Package size={14} color={Colors.neutral[500]} />
                    <Text style={styles.donationCardDetailText}>60 tablets</Text>
                  </View>
                  <View style={styles.donationCardDetail}>
                    <Clock size={14} color={Colors.neutral[500]} />
                    <Text style={styles.donationCardDetailText}>Expires Dec 2024</Text>
                  </View>
                </View>
                <View style={styles.donationCardFooter}>
                  <Text style={styles.pendingText}>
                    Awaiting pharmacist verification
                  </Text>
                  <ChevronRight size={20} color={Colors.neutral[400]} />
                </View>
              </View>
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity style={styles.viewAllButton}>
            <Text style={styles.viewAllButtonText}>View All Donations</Text>
            <ChevronRight size={16} color={Colors.primary[500]} />
          </TouchableOpacity>
        </Animated.View>
        
        <Animated.View 
          style={styles.sectionContainer}
          entering={FadeInDown.delay(300).springify()}
        >
          <Text style={styles.sectionTitle}>Account Settings</Text>
          <View style={styles.settingsMenu}>
            <TouchableOpacity style={styles.settingsItem}>
              <Text style={styles.settingsItemText}>Personal Information</Text>
              <ChevronRight size={20} color={Colors.neutral[400]} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.settingsItem}>
              <Text style={styles.settingsItemText}>Notification Preferences</Text>
              <ChevronRight size={20} color={Colors.neutral[400]} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.settingsItem}>
              <Text style={styles.settingsItemText}>Privacy Settings</Text>
              <ChevronRight size={20} color={Colors.neutral[400]} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.settingsItem, { borderBottomWidth: 0 }]}>
              <Text style={styles.settingsItemText}>Help & Support</Text>
              <ChevronRight size={20} color={Colors.neutral[400]} />
            </TouchableOpacity>
          </View>
        </Animated.View>

        <View style={styles.spacer} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    backgroundColor: Colors.white,
    padding: Layout.spacing.md,
    paddingBottom: Layout.spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  headerActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Layout.spacing.lg,
  },
  profileSection: {
    alignItems: 'center',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: Layout.spacing.md,
  },
  profileImageEditButton: {
    position: 'absolute',
    right: '35%',
    top: 70,
    backgroundColor: Colors.primary[500],
    borderRadius: Layout.borderRadius.full,
    width: 28,
    height: 28,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  userName: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  userLocation: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  userStats: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    paddingVertical: Layout.spacing.md,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 36,
    backgroundColor: Colors.neutral[200],
    marginHorizontal: Layout.spacing.xl,
  },
  sectionContainer: {
    padding: Layout.spacing.md,
    marginTop: Layout.spacing.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.md,
  },
  donationCards: {
    gap: Layout.spacing.md,
    marginBottom: Layout.spacing.md,
  },
  donationCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  donationStatusBadge: {
    height: 4,
    width: '100%',
  },
  donationStatusText: {
    display: 'none',
  },
  donationCardContent: {
    padding: Layout.spacing.md,
  },
  donationCardHeader: {
    marginBottom: Layout.spacing.sm,
  },
  donationCardTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  donationCardDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[400],
    flexDirection: 'row',
    alignItems: 'center',
  },
  donationCardDetails: {
    flexDirection: 'row',
    marginBottom: Layout.spacing.sm,
    flexWrap: 'wrap',
  },
  donationCardDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: Layout.spacing.md,
    marginBottom: 4,
  },
  donationCardDetailText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    marginLeft: 4,
  },
  donationCardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Layout.spacing.xs,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  verifiedText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.success[600],
  },
  pendingText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.warning[600],
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Layout.spacing.sm,
  },
  viewAllButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.primary[500],
    marginRight: 4,
  },
  settingsMenu: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  settingsItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Layout.spacing.md,
    paddingHorizontal: Layout.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  settingsItemText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[800],
  },
  spacer: {
    height: 100,
  },
});