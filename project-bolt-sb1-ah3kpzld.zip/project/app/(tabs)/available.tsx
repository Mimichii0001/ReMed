import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Filter, Search } from 'lucide-react-native';
import MedicineCard from '@/components/MedicineCard';
import { Medicine } from '@/types';

// Mock data for available medicines
const MOCK_MEDICINES: Medicine[] = [
  {
    id: '1',
    name: 'Amoxicillin',
    type: 'Antibiotic',
    expiryDate: 'Jan 2025',
    distance: '2.3',
    quantity: '30 tablets',
    strength: '500mg',
    imageUrl: 'https://images.pexels.com/photos/139398/himalayas-mountains-nepal-hill-139398.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'John D.',
    verificationDate: '2 days ago',
  },
  {
    id: '2',
    name: 'Metformin',
    type: 'Diabetes',
    expiryDate: 'Dec 2024',
    distance: '0.8',
    quantity: '60 tablets',
    strength: '1000mg',
    imageUrl: 'https://images.pexels.com/photos/208512/pexels-photo-208512.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Sarah M.',
    verificationDate: '5 days ago',
  },
  {
    id: '3',
    name: 'Lisinopril',
    type: 'Blood Pressure',
    expiryDate: 'Mar 2025',
    distance: '3.5',
    quantity: '45 tablets',
    strength: '10mg',
    imageUrl: 'https://images.pexels.com/photos/669621/pexels-photo-669621.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Emily K.',
    verificationDate: '1 day ago',
  },
  {
    id: '4',
    name: 'Atorvastatin',
    type: 'Cholesterol',
    expiryDate: 'Feb 2025',
    distance: '1.5',
    quantity: '30 tablets',
    strength: '20mg',
    imageUrl: 'https://images.pexels.com/photos/2089799/pexels-photo-2089799.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Robert J.',
    verificationDate: '3 days ago',
  },
  {
    id: '5',
    name: 'Levothyroxine',
    type: 'Thyroid',
    expiryDate: 'Nov 2024',
    distance: '4.2',
    quantity: '90 tablets',
    strength: '50mcg',
    imageUrl: 'https://images.pexels.com/photos/1089438/pexels-photo-1089438.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Patricia L.',
    verificationDate: '1 week ago',
  },
];

export default function AvailableScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [medicines, setMedicines] = useState(MOCK_MEDICINES);
  
  // Filter medicines based on search query
  const filteredMedicines = medicines.filter(medicine => 
    medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    medicine.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Available Medicines</Text>
        <Text style={styles.subtitle}>
          All donations have been verified by licensed pharmacists
        </Text>
      </View>
      
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color={Colors.neutral[400]} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by name or type..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity style={styles.filterButton}>
          <Filter size={20} color={Colors.neutral[600]} />
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={filteredMedicines}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <MedicineCard medicine={item} />
        )}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No medicines found</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    paddingHorizontal: Layout.spacing.md,
    paddingTop: Layout.spacing.md,
    paddingBottom: Layout.spacing.md,
    backgroundColor: Colors.white,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    lineHeight: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.neutral[100],
    borderRadius: Layout.borderRadius.md,
    paddingHorizontal: Layout.spacing.sm,
    marginRight: Layout.spacing.sm,
  },
  searchIcon: {
    marginRight: Layout.spacing.xs,
  },
  searchInput: {
    flex: 1,
    paddingVertical: Layout.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
  },
  filterButton: {
    width: 46,
    height: 46,
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: {
    padding: Layout.spacing.md,
    paddingBottom: 100, // Extra padding at bottom for tab bar
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Layout.spacing.xxl,
  },
  emptyText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[400],
  },
});