import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  TextInput,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Camera, Calendar, Pill, Image as ImageIcon } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import DonationSubmitted from '@/components/screens/DonationSubmitted';

export default function DonateScreen() {
  const router = useRouter();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    medicineName: '',
    expiryDate: '',
    quantity: '',
    description: '',
  });

  const handleSubmit = () => {
    // In a real app, we would validate and send the data to a backend
    setSubmitted(true);
  };

  if (submitted) {
    return <DonationSubmitted />;
  }

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.title}>Donate Medicine</Text>
          <Text style={styles.subtitle}>
            Please provide accurate information about the medicine you wish to donate
          </Text>
          
          <View style={styles.formContainer}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Medicine Name *</Text>
              <View style={styles.inputContainer}>
                <Pill size={20} color={Colors.primary[400]} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Enter medicine name"
                  value={formData.medicineName}
                  onChangeText={(text) => setFormData({...formData, medicineName: text})}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Expiry Date *</Text>
              <View style={styles.inputContainer}>
                <Calendar size={20} color={Colors.primary[400]} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="MM/YYYY"
                  value={formData.expiryDate}
                  onChangeText={(text) => setFormData({...formData, expiryDate: text})}
                  keyboardType="numbers-and-punctuation"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Quantity *</Text>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Number of units/tablets"
                  value={formData.quantity}
                  onChangeText={(text) => setFormData({...formData, quantity: text})}
                  keyboardType="number-pad"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Description</Text>
              <View style={[styles.inputContainer, styles.textAreaContainer]}>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Additional details about the medicine's condition, packaging, etc."
                  value={formData.description}
                  onChangeText={(text) => setFormData({...formData, description: text})}
                  multiline
                  numberOfLines={4}
                  textAlignVertical="top"
                />
              </View>
            </View>

            <View style={styles.imageUploadContainer}>
              <Text style={styles.label}>Upload Photos (Optional)</Text>
              <TouchableOpacity style={styles.imageUploadButton}>
                <View style={styles.imageUploadContent}>
                  <View style={styles.imageIconContainer}>
                    <ImageIcon size={24} color={Colors.primary[500]} />
                  </View>
                  <Text style={styles.imageUploadText}>Tap to add photos</Text>
                  <Text style={styles.imageUploadSubtext}>Show the medicine packaging and expiry date</Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.infoBox}>
              <Text style={styles.infoTitle}>Verification Process</Text>
              <Text style={styles.infoText}>
                A licensed pharmacist will review your submission to ensure it meets safety standards before making it available for redistribution.
              </Text>
            </View>

            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmit}
              activeOpacity={0.8}
            >
              <Text style={styles.submitButtonText}>Submit Donation</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  scrollContainer: {
    paddingHorizontal: Layout.spacing.md,
    paddingTop: Layout.spacing.md,
    paddingBottom: Layout.spacing.xxl,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[500],
    marginBottom: Layout.spacing.xl,
    lineHeight: 22,
  },
  formContainer: {
    gap: Layout.spacing.lg,
  },
  inputGroup: {
    gap: Layout.spacing.xs,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[700],
    marginBottom: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.spacing.sm,
  },
  inputIcon: {
    marginRight: Layout.spacing.xs,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
    paddingVertical: Platform.OS === 'ios' ? 12 : 8,
  },
  textAreaContainer: {
    minHeight: 120,
    alignItems: 'flex-start',
  },
  textArea: {
    paddingTop: Layout.spacing.sm,
    height: 100,
  },
  imageUploadContainer: {
    marginTop: Layout.spacing.sm,
  },
  imageUploadButton: {
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderStyle: 'dashed',
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.neutral[50],
  },
  imageUploadContent: {
    alignItems: 'center',
    gap: Layout.spacing.xs,
  },
  imageIconContainer: {
    width: 48,
    height: 48,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.xs,
  },
  imageUploadText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.primary[600],
  },
  imageUploadSubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    textAlign: 'center',
  },
  infoBox: {
    backgroundColor: Colors.secondary[50],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    marginTop: Layout.spacing.md,
  },
  infoTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.secondary[700],
    marginBottom: 4,
  },
  infoText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.secondary[700],
    lineHeight: 20,
  },
  submitButton: {
    backgroundColor: Colors.primary[500],
    borderRadius: Layout.borderRadius.md,
    paddingVertical: Layout.spacing.md,
    alignItems: 'center',
    marginTop: Layout.spacing.lg,
  },
  submitButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
});