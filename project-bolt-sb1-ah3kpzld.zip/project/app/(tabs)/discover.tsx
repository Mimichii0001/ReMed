import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Linking
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { ArrowRight, ExternalLink } from 'lucide-react-native';

export default function DiscoverScreen() {
  // Function to open external links
  const openLink = (url: string) => {
    Linking.openURL(url);
  };

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>Discover</Text>
          <Text style={styles.subtitle}>
            Learn more about medicine donation and how it helps communities
          </Text>
        </View>

        <View style={styles.featuredCard}>
          <Image
            source={{ uri: "https://images.pexels.com/photos/6823573/pexels-photo-6823573.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" }}
            style={styles.featuredImage}
          />
          <View style={styles.featuredContent}>
            <View style={styles.featuredBadge}>
              <Text style={styles.featuredBadgeText}>FEATURED</Text>
            </View>
            <Text style={styles.featuredTitle}>Why Medicine Donation Matters</Text>
            <Text style={styles.featuredDescription}>
              Each year, billions of dollars worth of medications go unused and are disposed of improperly.
            </Text>
            <TouchableOpacity 
              style={styles.featuredButton}
              onPress={() => {}}
            >
              <Text style={styles.featuredButtonText}>Read More</Text>
              <ArrowRight size={16} color={Colors.white} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>How It Works</Text>
          <View style={styles.infoCards}>
            <View style={styles.infoCard}>
              <View style={[styles.infoCardIcon, { backgroundColor: Colors.primary[50] }]}>
                <Text style={[styles.infoCardIconText, { color: Colors.primary[500] }]}>1</Text>
              </View>
              <Text style={styles.infoCardTitle}>Donate</Text>
              <Text style={styles.infoCardDescription}>
                Submit details of unused, unexpired medicine through our secure platform
              </Text>
            </View>
            <View style={styles.infoCard}>
              <View style={[styles.infoCardIcon, { backgroundColor: Colors.secondary[50] }]}>
                <Text style={[styles.infoCardIconText, { color: Colors.secondary[500] }]}>2</Text>
              </View>
              <Text style={styles.infoCardTitle}>Verify</Text>
              <Text style={styles.infoCardDescription}>
                Licensed pharmacists review each submission for quality and safety
              </Text>
            </View>
            <View style={styles.infoCard}>
              <View style={[styles.infoCardIcon, { backgroundColor: Colors.accent[50] }]}>
                <Text style={[styles.infoCardIconText, { color: Colors.accent[500] }]}>3</Text>
              </View>
              <Text style={styles.infoCardTitle}>Distribute</Text>
              <Text style={styles.infoCardDescription}>
                Approved medicines become available to those in need through our network
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Resources</Text>
          <View style={styles.resourceCards}>
            <TouchableOpacity 
              style={styles.resourceCard}
              onPress={() => {}}
            >
              <Text style={styles.resourceCardTitle}>Donation Guidelines</Text>
              <Text style={styles.resourceCardDescription}>
                Learn which medicines can be donated and under what conditions
              </Text>
              <View style={styles.resourceCardButton}>
                <ArrowRight size={16} color={Colors.primary[500]} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.resourceCard}
              onPress={() => {}}
            >
              <Text style={styles.resourceCardTitle}>Safety Standards</Text>
              <Text style={styles.resourceCardDescription}>
                Understand our strict verification process to ensure medicine safety
              </Text>
              <View style={styles.resourceCardButton}>
                <ArrowRight size={16} color={Colors.primary[500]} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.resourceCard}
              onPress={() => {}}
            >
              <Text style={styles.resourceCardTitle}>FAQs</Text>
              <Text style={styles.resourceCardDescription}>
                Get answers to commonly asked questions about medicine donation
              </Text>
              <View style={styles.resourceCardButton}>
                <ArrowRight size={16} color={Colors.primary[500]} />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.externalResourcesSection}>
          <Text style={styles.sectionTitle}>External Resources</Text>
          <TouchableOpacity 
            style={styles.externalLink}
            onPress={() => openLink('https://www.fda.gov/')}
          >
            <Text style={styles.externalLinkText}>FDA Medication Guidelines</Text>
            <ExternalLink size={16} color={Colors.primary[500]} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.externalLink}
            onPress={() => openLink('https://www.who.int/')}
          >
            <Text style={styles.externalLinkText}>WHO Medication Donation Standards</Text>
            <ExternalLink size={16} color={Colors.primary[500]} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.externalLink}
            onPress={() => openLink('https://www.cdc.gov/')}
          >
            <Text style={styles.externalLinkText}>CDC Safe Medication Practices</Text>
            <ExternalLink size={16} color={Colors.primary[500]} />
          </TouchableOpacity>
        </View>

        <View style={styles.spacer} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    paddingHorizontal: Layout.spacing.md,
    paddingTop: Layout.spacing.md,
    paddingBottom: Layout.spacing.md,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[500],
    lineHeight: 22,
  },
  featuredCard: {
    marginHorizontal: Layout.spacing.md,
    marginVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    overflow: 'hidden',
    backgroundColor: Colors.white,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 2,
  },
  featuredImage: {
    width: '100%',
    height: 180,
    resizeMode: 'cover',
  },
  featuredContent: {
    padding: Layout.spacing.md,
  },
  featuredBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.accent[500],
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: 4,
    borderRadius: Layout.borderRadius.full,
    marginBottom: Layout.spacing.sm,
  },
  featuredBadgeText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 10,
    color: Colors.white,
  },
  featuredTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  featuredDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 21,
    marginBottom: Layout.spacing.sm,
  },
  featuredButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    alignSelf: 'flex-start',
    gap: 8,
  },
  featuredButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  sectionContainer: {
    marginTop: Layout.spacing.lg,
    paddingHorizontal: Layout.spacing.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.md,
  },
  infoCards: {
    gap: Layout.spacing.md,
  },
  infoCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  infoCardIcon: {
    width: 36,
    height: 36,
    borderRadius: Layout.borderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.sm,
  },
  infoCardIconText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
  },
  infoCardTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  infoCardDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
  },
  resourceCards: {
    gap: Layout.spacing.md,
  },
  resourceCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  resourceCardTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
    width: '85%',
  },
  resourceCardDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
    width: '85%',
  },
  resourceCardButton: {
    position: 'absolute',
    right: Layout.spacing.md,
    top: '50%',
    marginTop: -8,
  },
  externalResourcesSection: {
    marginTop: Layout.spacing.lg,
    paddingHorizontal: Layout.spacing.md,
    marginBottom: Layout.spacing.lg,
  },
  externalLink: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Layout.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
  },
  externalLinkText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.primary[600],
  },
  spacer: {
    height: 100,
  },
});