import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity 
} from 'react-native';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { MapPin, Calendar, Shield } from 'lucide-react-native';
import { Medicine } from '@/types';
import Animated, { FadeIn } from 'react-native-reanimated';

interface MedicineCardProps {
  medicine: Medicine;
}

export default function MedicineCard({ medicine }: MedicineCardProps) {
  return (
    <Animated.View 
      entering={FadeIn.duration(400)}
      style={styles.container}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: medicine.imageUrl }}
          style={styles.image}
        />
        <View style={styles.typeTag}>
          <Text style={styles.typeText}>{medicine.type}</Text>
        </View>
      </View>
      
      <View style={styles.contentContainer}>
        <Text style={styles.title}>{medicine.name}</Text>
        <Text style={styles.strength}>{medicine.strength}</Text>
        
        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <Calendar size={14} color={Colors.neutral[500]} />
            <Text style={styles.detailText}>Expires: {medicine.expiryDate}</Text>
          </View>
          <View style={styles.detailItem}>
            <MapPin size={14} color={Colors.neutral[500]} />
            <Text style={styles.detailText}>{medicine.distance} miles</Text>
          </View>
        </View>
        
        <View style={styles.footer}>
          <View style={styles.verifiedContainer}>
            <Shield size={14} color={Colors.success[500]} />
            <Text style={styles.verifiedText}>
              Verified {medicine.verificationDate}
            </Text>
          </View>
          
          <TouchableOpacity style={styles.requestButton}>
            <Text style={styles.requestButtonText}>Request</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    overflow: 'hidden',
    marginBottom: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  imageContainer: {
    height: 140,
    width: '100%',
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  typeTag: {
    position: 'absolute',
    top: Layout.spacing.sm,
    left: Layout.spacing.sm,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: 4,
    borderRadius: Layout.borderRadius.full,
  },
  typeText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.white,
  },
  contentContainer: {
    padding: Layout.spacing.md,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  strength: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[500],
    marginBottom: Layout.spacing.sm,
  },
  detailsRow: {
    flexDirection: 'row',
    marginBottom: Layout.spacing.md,
    flexWrap: 'wrap',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: Layout.spacing.md,
    marginBottom: 4,
  },
  detailText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    marginLeft: 4,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Layout.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  verifiedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  verifiedText: {
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    color: Colors.success[700],
    marginLeft: 4,
  },
  requestButton: {
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.xs,
    borderRadius: Layout.borderRadius.md,
  },
  requestButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
});