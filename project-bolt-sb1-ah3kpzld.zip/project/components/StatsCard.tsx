import React, { ReactNode } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';

interface StatsCardProps {
  icon: ReactNode;
  title: string;
  value: string;
  subtitle: string;
  color: string;
}

export default function StatsCard({ icon, title, value, subtitle, color }: StatsCardProps) {
  return (
    <View style={[styles.container, { backgroundColor: color }]}>
      <View style={styles.iconContainer}>
        {icon}
      </View>
      <View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.value}>{value}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    backgroundColor: Colors.primary[50],
  },
  iconContainer: {
    marginRight: Layout.spacing.md,
  },
  title: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[600],
    marginBottom: 2,
  },
  value: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[500],
  },
});