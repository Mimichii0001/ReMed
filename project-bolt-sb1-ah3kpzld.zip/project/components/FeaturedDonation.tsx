import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity 
} from 'react-native';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { MapPin, Clock } from 'lucide-react-native';

interface FeaturedDonationProps {
  name: string;
  type: string;
  distance: string;
  expiryDate: string;
  imageUrl: string;
}

export default function FeaturedDonation({
  name,
  type,
  distance,
  expiryDate,
  imageUrl
}: FeaturedDonationProps) {
  return (
    <TouchableOpacity style={styles.container}>
      <Image
        source={{ uri: imageUrl }}
        style={styles.image}
      />
      <View style={styles.content}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.type}>{type}</Text>
        
        <View style={styles.details}>
          <View style={styles.detailItem}>
            <MapPin size={12} color={Colors.neutral[500]} />
            <Text style={styles.detailText}>{distance}</Text>
          </View>
          <View style={styles.detailItem}>
            <Clock size={12} color={Colors.neutral[500]} />
            <Text style={styles.detailText}>{expiryDate}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 160,
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.white,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    marginRight: Layout.spacing.md,
  },
  image: {
    width: '100%',
    height: 100,
    resizeMode: 'cover',
  },
  content: {
    padding: Layout.spacing.sm,
  },
  name: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
  },
  type: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[500],
    marginBottom: Layout.spacing.xs,
  },
  details: {
    marginTop: 4,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  detailText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[600],
    marginLeft: 4,
  },
});