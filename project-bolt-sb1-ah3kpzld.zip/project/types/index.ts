export interface Medicine {
  id: string;
  name: string;
  type: string;
  expiryDate: string;
  distance: string;
  quantity: string;
  strength: string;
  imageUrl: string;
  donorName: string;
  verificationDate: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  location: string;
  role: 'donor' | 'pharmacist' | 'admin';
  profileImageUrl?: string;
}

export interface Donation {
  id: string;
  medicineId: string;
  donorId: string;
  status: 'pending' | 'verified' | 'rejected';
  submissionDate: string;
  verificationDate?: string;
  verifiedBy?: string;
}