import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  ScrollView,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { X, Bell, Smartphone, Mail, Clock } from 'lucide-react-native';

interface NotificationSettingsProps {
  visible: boolean;
  onClose: () => void;
}

interface NotificationPreference {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
  type: 'push' | 'email' | 'sms';
}

export default function NotificationSettings({ visible, onClose }: NotificationSettingsProps) {
  const [preferences, setPreferences] = useState<NotificationPreference[]>([
    {
      id: 'medication_verified',
      title: 'Medication Verified',
      description: 'When your requested medication is verified and ready for pickup',
      enabled: true,
      type: 'push',
    },
    {
      id: 'pickup_reminders',
      title: 'Pickup Reminders',
      description: 'Reminders to pick up your medication before the deadline',
      enabled: true,
      type: 'push',
    },
    {
      id: 'request_updates',
      title: 'Request Updates',
      description: 'Updates on your medication requests and approvals',
      enabled: true,
      type: 'push',
    },
    {
      id: 'new_donations',
      title: 'New Donations',
      description: 'When new medications become available in your area',
      enabled: false,
      type: 'push',
    },
    {
      id: 'donation_status',
      title: 'Donation Status',
      description: 'Updates on medications you\'ve donated',
      enabled: true,
      type: 'push',
    },
    {
      id: 'email_summaries',
      title: 'Weekly Email Summary',
      description: 'Weekly summary of your activity and available medications',
      enabled: true,
      type: 'email',
    },
  ]);

  const [globalSettings, setGlobalSettings] = useState({
    pushNotifications: true,
    emailNotifications: true,
    smsNotifications: false,
    quietHours: true,
    quietStart: '22:00',
    quietEnd: '08:00',
  });

  const togglePreference = (id: string) => {
    setPreferences(prev =>
      prev.map(pref =>
        pref.id === id ? { ...pref, enabled: !pref.enabled } : pref
      )
    );
  };

  const toggleGlobalSetting = (setting: keyof typeof globalSettings) => {
    setGlobalSettings(prev => ({
      ...prev,
      [setting]: !prev[setting],
    }));
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'push':
        return <Smartphone size={16} color={Colors.primary[500]} />;
      case 'email':
        return <Mail size={16} color={Colors.secondary[500]} />;
      case 'sms':
        return <Bell size={16} color={Colors.accent[500]} />;
      default:
        return <Bell size={16} color={Colors.neutral[500]} />;
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
        <View style={styles.header}>
          <Text style={styles.title}>Notification Settings</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={onClose}
          >
            <X size={24} color={Colors.neutral[600]} />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Global Settings */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>General Settings</Text>
            
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <View style={styles.settingHeader}>
                  <Smartphone size={20} color={Colors.primary[500]} />
                  <Text style={styles.settingTitle}>Push Notifications</Text>
                </View>
                <Text style={styles.settingDescription}>
                  Receive notifications on your device
                </Text>
              </View>
              <Switch
                value={globalSettings.pushNotifications}
                onValueChange={() => toggleGlobalSetting('pushNotifications')}
                trackColor={{ false: Colors.neutral[200], true: Colors.primary[200] }}
                thumbColor={globalSettings.pushNotifications ? Colors.primary[500] : Colors.neutral[400]}
              />
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <View style={styles.settingHeader}>
                  <Mail size={20} color={Colors.secondary[500]} />
                  <Text style={styles.settingTitle}>Email Notifications</Text>
                </View>
                <Text style={styles.settingDescription}>
                  Receive notifications via email
                </Text>
              </View>
              <Switch
                value={globalSettings.emailNotifications}
                onValueChange={() => toggleGlobalSetting('emailNotifications')}
                trackColor={{ false: Colors.neutral[200], true: Colors.primary[200] }}
                thumbColor={globalSettings.emailNotifications ? Colors.primary[500] : Colors.neutral[400]}
              />
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <View style={styles.settingHeader}>
                  <Clock size={20} color={Colors.accent[500]} />
                  <Text style={styles.settingTitle}>Quiet Hours</Text>
                </View>
                <Text style={styles.settingDescription}>
                  No notifications between 10 PM - 8 AM
                </Text>
              </View>
              <Switch
                value={globalSettings.quietHours}
                onValueChange={() => toggleGlobalSetting('quietHours')}
                trackColor={{ false: Colors.neutral[200], true: Colors.primary[200] }}
                thumbColor={globalSettings.quietHours ? Colors.primary[500] : Colors.neutral[400]}
              />
            </View>
          </View>

          {/* Notification Types */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notification Types</Text>
            <Text style={styles.sectionDescription}>
              Choose which notifications you want to receive
            </Text>

            {preferences.map((preference) => (
              <View key={preference.id} style={styles.preferenceItem}>
                <View style={styles.preferenceInfo}>
                  <View style={styles.preferenceHeader}>
                    <Text style={styles.preferenceTitle}>{preference.title}</Text>
                    <View style={styles.typeIndicator}>
                      {getTypeIcon(preference.type)}
                    </View>
                  </View>
                  <Text style={styles.preferenceDescription}>
                    {preference.description}
                  </Text>
                </View>
                <Switch
                  value={preference.enabled}
                  onValueChange={() => togglePreference(preference.id)}
                  trackColor={{ false: Colors.neutral[200], true: Colors.primary[200] }}
                  thumbColor={preference.enabled ? Colors.primary[500] : Colors.neutral[400]}
                />
              </View>
            ))}
          </View>

          {/* Important Notice */}
          <View style={styles.noticeSection}>
            <View style={styles.noticeCard}>
              <Bell size={24} color={Colors.warning[500]} />
              <View style={styles.noticeContent}>
                <Text style={styles.noticeTitle}>Important</Text>
                <Text style={styles.noticeText}>
                  We recommend keeping medication verification and pickup reminder notifications enabled to ensure you don't miss important updates about your requested medications.
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.bottomSpacer} />
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: Colors.white,
    marginTop: Layout.spacing.lg,
    paddingVertical: Layout.spacing.lg,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    paddingHorizontal: Layout.spacing.lg,
    marginBottom: Layout.spacing.xs,
  },
  sectionDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    paddingHorizontal: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    lineHeight: 20,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  settingInfo: {
    flex: 1,
    marginRight: Layout.spacing.md,
  },
  settingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.xs,
  },
  settingTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  settingDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    lineHeight: 20,
  },
  preferenceItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  preferenceInfo: {
    flex: 1,
    marginRight: Layout.spacing.md,
  },
  preferenceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Layout.spacing.xs,
  },
  preferenceTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
  },
  typeIndicator: {
    backgroundColor: Colors.neutral[100],
    borderRadius: Layout.borderRadius.full,
    padding: 4,
  },
  preferenceDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    lineHeight: 20,
  },
  noticeSection: {
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.lg,
  },
  noticeCard: {
    flexDirection: 'row',
    backgroundColor: Colors.warning[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    borderWidth: 1,
    borderColor: Colors.warning[200],
  },
  noticeContent: {
    flex: 1,
    marginLeft: Layout.spacing.md,
  },
  noticeTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.warning[800],
    marginBottom: Layout.spacing.xs,
  },
  noticeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.warning[700],
    lineHeight: 20,
  },
  bottomSpacer: {
    height: Layout.spacing.xxl,
  },
});