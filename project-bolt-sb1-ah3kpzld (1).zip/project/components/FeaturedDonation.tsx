import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity 
} from 'react-native';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';

interface FeaturedDonationProps {
  name: string;
  type: string;
  distance: string;
  expiryDate: string;
  imageUrl: string;
}

export default function FeaturedDonation({
  name,
  type,
  distance,
  expiryDate,
  imageUrl
}: FeaturedDonationProps) {
  return (
    <TouchableOpacity style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.type}>{type}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 120,
    borderRadius: Layout.borderRadius.lg,
    backgroundColor: Colors.white,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    marginRight: Layout.spacing.md,
  },
  content: {
    padding: Layout.spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 80,
  },
  name: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.neutral[800],
    textAlign: 'center',
    marginBottom: Layout.spacing.xs,
  },
  type: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.primary[600],
    textAlign: 'center',
  },
});