import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Star, X, MessageSquare } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

interface DonationRatingProps {
  visible: boolean;
  onClose: () => void;
  donationId: string;
  medicationName: string;
  pharmacyName: string;
  onSubmitRating?: (rating: number, comment: string) => void;
}

export default function DonationRating({ 
  visible, 
  onClose, 
  donationId, 
  medicationName, 
  pharmacyName,
  onSubmitRating 
}: DonationRatingProps) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [hoveredStar, setHoveredStar] = useState(0);

  const handleStarPress = (starRating: number) => {
    setRating(starRating);
  };

  const handleSubmit = () => {
    if (rating === 0) {
      Alert.alert('Rating Required', 'Please select a star rating before submitting.');
      return;
    }

    if (onSubmitRating) {
      onSubmitRating(rating, comment);
    }

    Alert.alert(
      'Thank You!',
      'Your rating has been submitted successfully. Your feedback helps us improve the donation experience.',
      [
        {
          text: 'OK',
          onPress: () => {
            setRating(0);
            setComment('');
            onClose();
          },
        },
      ]
    );
  };

  const getRatingText = (stars: number) => {
    switch (stars) {
      case 1:
        return 'Poor';
      case 2:
        return 'Fair';
      case 3:
        return 'Good';
      case 4:
        return 'Very Good';
      case 5:
        return 'Excellent';
      default:
        return 'Select a rating';
    }
  };

  const getRatingColor = (stars: number) => {
    if (stars <= 2) return Colors.error[500];
    if (stars === 3) return Colors.warning[500];
    return Colors.success[500];
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      transparent={false}
    >
      <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
        <View style={styles.header}>
          <Text style={styles.title}>Rate This Donation Experience</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={onClose}
          >
            <X size={24} color={Colors.neutral[600]} />
          </TouchableOpacity>
        </View>

        <View style={styles.content}>
          <Animated.View 
            style={styles.donationInfo}
            entering={FadeInDown.delay(100).springify()}
          >
            <Text style={styles.medicationName}>{medicationName}</Text>
            <Text style={styles.pharmacyName}>from {pharmacyName}</Text>
          </Animated.View>

          <Animated.View 
            style={styles.ratingSection}
            entering={FadeInDown.delay(200).springify()}
          >
            <Text style={styles.ratingLabel}>How was your experience?</Text>
            
            <View style={styles.starsContainer}>
              {[1, 2, 3, 4, 5].map((star) => (
                <TouchableOpacity
                  key={star}
                  style={styles.starButton}
                  onPress={() => handleStarPress(star)}
                  onPressIn={() => setHoveredStar(star)}
                  onPressOut={() => setHoveredStar(0)}
                >
                  <Star
                    size={40}
                    color={
                      star <= (hoveredStar || rating)
                        ? Colors.warning[500]
                        : Colors.neutral[300]
                    }
                    fill={
                      star <= (hoveredStar || rating)
                        ? Colors.warning[500]
                        : 'transparent'
                    }
                  />
                </TouchableOpacity>
              ))}
            </View>

            {rating > 0 && (
              <Animated.View 
                style={styles.ratingTextContainer}
                entering={FadeInDown.delay(100).springify()}
              >
                <Text style={[
                  styles.ratingText,
                  { color: getRatingColor(rating) }
                ]}>
                  {getRatingText(rating)}
                </Text>
              </Animated.View>
            )}
          </Animated.View>

          <Animated.View 
            style={styles.commentSection}
            entering={FadeInDown.delay(300).springify()}
          >
            <View style={styles.commentHeader}>
              <MessageSquare size={20} color={Colors.neutral[600]} />
              <Text style={styles.commentLabel}>
                Additional Comments (Optional)
              </Text>
            </View>
            
            <View style={styles.commentInputContainer}>
              <TextInput
                style={styles.commentInput}
                placeholder="Share your experience to help us improve..."
                value={comment}
                onChangeText={setComment}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                maxLength={500}
              />
              <Text style={styles.characterCount}>
                {comment.length}/500
              </Text>
            </View>
          </Animated.View>

          <Animated.View 
            style={styles.helpSection}
            entering={FadeInDown.delay(400).springify()}
          >
            <Text style={styles.helpTitle}>Your feedback helps us:</Text>
            <View style={styles.helpList}>
              <Text style={styles.helpItem}>• Improve the donation process</Text>
              <Text style={styles.helpItem}>• Enhance pharmacy partnerships</Text>
              <Text style={styles.helpItem}>• Better serve the community</Text>
            </View>
          </Animated.View>
        </View>

        <View style={styles.footer}>
          <TouchableOpacity
            style={[
              styles.submitButton,
              rating === 0 && styles.submitButtonDisabled
            ]}
            onPress={handleSubmit}
            disabled={rating === 0}
          >
            <Text style={[
              styles.submitButtonText,
              rating === 0 && styles.submitButtonTextDisabled
            ]}>
              Submit Rating
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.skipButton}
            onPress={onClose}
          >
            <Text style={styles.skipButtonText}>Skip for now</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    flex: 1,
    marginRight: Layout.spacing.md,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    padding: Layout.spacing.lg,
  },
  donationInfo: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  medicationName: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.primary[700],
    textAlign: 'center',
    marginBottom: Layout.spacing.xs,
  },
  pharmacyName: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[600],
    textAlign: 'center',
  },
  ratingSection: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  ratingLabel: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.lg,
    textAlign: 'center',
  },
  starsContainer: {
    flexDirection: 'row',
    gap: Layout.spacing.sm,
    marginBottom: Layout.spacing.md,
  },
  starButton: {
    padding: Layout.spacing.xs,
  },
  ratingTextContainer: {
    backgroundColor: Colors.neutral[50],
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.full,
  },
  ratingText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    textAlign: 'center',
  },
  commentSection: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  commentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  commentLabel: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  commentInputContainer: {
    position: 'relative',
  },
  commentInput: {
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
    minHeight: 100,
    backgroundColor: Colors.neutral[50],
  },
  characterCount: {
    position: 'absolute',
    bottom: Layout.spacing.xs,
    right: Layout.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[400],
    backgroundColor: Colors.white,
    paddingHorizontal: 4,
  },
  helpSection: {
    backgroundColor: Colors.primary[25],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    borderWidth: 1,
    borderColor: Colors.primary[100],
  },
  helpTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.primary[800],
    marginBottom: Layout.spacing.sm,
  },
  helpList: {
    gap: 4,
  },
  helpItem: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.primary[700],
    lineHeight: 20,
  },
  footer: {
    padding: Layout.spacing.lg,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
    gap: Layout.spacing.sm,
  },
  submitButton: {
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    alignItems: 'center',
  },
  submitButtonDisabled: {
    backgroundColor: Colors.neutral[200],
  },
  submitButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
  submitButtonTextDisabled: {
    color: Colors.neutral[400],
  },
  skipButton: {
    paddingVertical: Layout.spacing.sm,
    alignItems: 'center',
  },
  skipButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[500],
  },
});