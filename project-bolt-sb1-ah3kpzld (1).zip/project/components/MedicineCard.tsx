import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity 
} from 'react-native';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { MapPin, Calendar, Shield, Bell, Pill, Building2 } from 'lucide-react-native';
import { Medicine } from '@/types';
import Animated, { FadeIn } from 'react-native-reanimated';

interface MedicineCardProps {
  medicine: Medicine;
  onRequest?: (medicine: Medicine) => void;
}

export default function MedicineCard({ medicine, onRequest }: MedicineCardProps) {
  const handleRequest = () => {
    if (onRequest) {
      onRequest(medicine);
    }
  };

  return (
    <Animated.View 
      entering={FadeIn.duration(400)}
      style={styles.container}
    >
      {/* Medicine Icon Header */}
      <View style={styles.iconHeader}>
        <View style={styles.medicineIconContainer}>
          <Pill size={24} color={Colors.primary[500]} />
        </View>
        <View style={styles.typeTag}>
          <Text style={styles.typeText}>{medicine.type}</Text>
        </View>
      </View>
      
      <View style={styles.contentContainer}>
        <View style={styles.titleSection}>
          <Text style={styles.title}>{medicine.name}</Text>
          <Text style={styles.strength}>{medicine.strength}</Text>
        </View>
        
        <View style={styles.detailsSection}>
          <View style={styles.detailsRow}>
            <View style={styles.detailItem}>
              <Calendar size={14} color={Colors.neutral[500]} />
              <Text style={styles.detailText}>Expires: {medicine.expiryDate}</Text>
            </View>
            <View style={styles.detailItem}>
              <MapPin size={14} color={Colors.neutral[500]} />
              <Text style={styles.detailText}>{medicine.distance} miles</Text>
            </View>
          </View>
        </View>

        {/* Pharmacy Information */}
        <View style={styles.pharmacySection}>
          <View style={styles.pharmacyInfo}>
            <Building2 size={14} color={Colors.secondary[500]} />
            <Text style={styles.pharmacyName}>{medicine.pharmacy.name}</Text>
          </View>
        </View>
        
        <View style={styles.footer}>
          <View style={styles.verifiedContainer}>
            <Shield size={14} color={Colors.success[500]} />
            <Text style={styles.verifiedText}>
              Verified {medicine.verificationDate}
            </Text>
          </View>
          
          <TouchableOpacity 
            style={styles.requestButton}
            onPress={handleRequest}
          >
            <Bell size={14} color={Colors.white} />
            <Text style={styles.requestButtonText}>Request</Text>
          </TouchableOpacity>
        </View>

        {/* Donor Information - Made more subtle */}
        <View style={styles.donorSection}>
          <Text style={styles.donorText}>
            Donated by {medicine.donorName}
          </Text>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    overflow: 'hidden',
    marginBottom: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  iconHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.primary[50],
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.primary[100],
  },
  medicineIconContainer: {
    width: 48,
    height: 48,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  typeTag: {
    backgroundColor: Colors.warning[500],
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: Layout.spacing.xs,
    borderRadius: Layout.borderRadius.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
    borderWidth: 1,
    borderColor: Colors.warning[600],
  },
  typeText: {
    fontFamily: 'Inter-Bold',
    fontSize: 11,
    color: Colors.white,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  contentContainer: {
    padding: Layout.spacing.md,
  },
  titleSection: {
    marginBottom: Layout.spacing.md,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: 4,
  },
  strength: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.primary[600],
  },
  detailsSection: {
    marginBottom: Layout.spacing.md,
  },
  detailsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Layout.spacing.md,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  detailText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    marginLeft: 4,
  },
  pharmacySection: {
    backgroundColor: Colors.secondary[25],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.sm,
    marginBottom: Layout.spacing.md,
    borderWidth: 1,
    borderColor: Colors.secondary[100],
  },
  pharmacyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  pharmacyName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.secondary[700],
    marginLeft: Layout.spacing.xs,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Layout.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
    marginBottom: Layout.spacing.sm,
  },
  verifiedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  verifiedText: {
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    color: Colors.success[700],
    marginLeft: 4,
  },
  requestButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.xs,
    borderRadius: Layout.borderRadius.md,
    gap: 4,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  requestButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  donorSection: {
    paddingTop: Layout.spacing.xs,
  },
  donorText: {
    fontFamily: 'Inter-Regular',
    fontSize: 11,
    color: '#999999',
    textAlign: 'center',
  },
});