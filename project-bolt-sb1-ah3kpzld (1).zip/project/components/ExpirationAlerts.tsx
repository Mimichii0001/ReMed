import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { TriangleAlert as AlertTriangle, X, Calendar, Package, MapPin, Phone, Trash2, RefreshCw, Clock } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

interface ExpiringMedication {
  id: string;
  name: string;
  strength: string;
  expiryDate: string;
  daysUntilExpiry: number;
  quantity: string;
  donorName: string;
  pharmacyName: string;
  pharmacyAddress: string;
  pharmacyPhone: string;
  status: 'warning' | 'expired';
  lastChecked: string;
  imageUrl: string;
}

const MOCK_EXPIRING_MEDICATIONS: ExpiringMedication[] = [
  {
    id: '2',
    name: 'Metformin',
    strength: '1000mg',
    expiryDate: 'Jan 10, 2025',
    daysUntilExpiry: 120,
    quantity: '60 tablets',
    donorName: 'Sarah M.',
    pharmacyName: 'Community Health Pharmacy',
    pharmacyAddress: '456 Oak Ave, San Francisco, CA 94103',
    pharmacyPhone: '(415) 555-0456',
    status: 'warning',
    lastChecked: '1 day ago',
    imageUrl: 'https://images.pexels.com/photos/208512/pexels-photo-208512.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: '3',
    name: 'Lisinopril',
    strength: '10mg',
    expiryDate: 'Jan 5, 2025',
    daysUntilExpiry: -3,
    quantity: '45 tablets',
    donorName: 'Emily K.',
    pharmacyName: 'Wellness Pharmacy Plus',
    pharmacyAddress: '789 Pine St, San Francisco, CA 94108',
    pharmacyPhone: '(415) 555-0789',
    status: 'expired',
    lastChecked: '5 days ago',
    imageUrl: 'https://images.pexels.com/photos/669621/pexels-photo-669621.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
];

interface ExpirationAlertsProps {
  visible: boolean;
  onClose: () => void;
  userRole?: 'donor' | 'pharmacist' | 'admin';
}

export default function ExpirationAlerts({ visible, onClose, userRole = 'donor' }: ExpirationAlertsProps) {
  const [medications, setMedications] = useState(MOCK_EXPIRING_MEDICATIONS);
  const [selectedMedication, setSelectedMedication] = useState<ExpiringMedication | null>(null);
  const [filter, setFilter] = useState<'all' | 'warning' | 'expired'>('all');

  const filteredMedications = medications.filter(med => 
    filter === 'all' || med.status === filter
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'warning':
        return Colors.warning[500];
      case 'expired':
        return Colors.neutral[500];
      default:
        return Colors.neutral[400];
    }
  };

  const getStatusText = (status: string, days: number) => {
    if (status === 'expired') {
      return `Expired ${Math.abs(days)} days ago`;
    }
    if (days <= 180) { // Less than 6 months
      return `This medication expires in less than 6 months. Some pharmacies may not accept it`;
    }
    return `Expires in ${days} days`;
  };

  const handleRemoveMedication = (medicationId: string) => {
    Alert.alert(
      'Remove Medication',
      'Are you sure you want to remove this medication from the system? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            setMedications(prev => prev.filter(med => med.id !== medicationId));
            setSelectedMedication(null);
            Alert.alert('Success', 'Medication has been removed from the system.');
          },
        },
      ]
    );
  };

  const handleRecheckExpiry = (medicationId: string) => {
    Alert.alert(
      'Recheck Expiry Date',
      'Please verify the expiry date on the medication packaging and update if necessary.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirmed Valid',
          onPress: () => {
            setMedications(prev => 
              prev.map(med => 
                med.id === medicationId 
                  ? { ...med, lastChecked: 'Just now', daysUntilExpiry: med.daysUntilExpiry + 30 }
                  : med
              )
            );
            Alert.alert('Success', 'Expiry date has been verified and updated.');
          },
        },
      ]
    );
  };

  const renderMedicationCard = ({ item }: { item: ExpiringMedication }) => (
    <Animated.View entering={FadeInDown.delay(100)}>
      <TouchableOpacity
        style={[
          styles.medicationCard,
          { borderLeftColor: getStatusColor(item.status) }
        ]}
        onPress={() => setSelectedMedication(item)}
      >
        <View style={styles.cardHeader}>
          <View style={styles.medicationInfo}>
            <Text style={styles.medicationName}>{item.name}</Text>
            <Text style={styles.medicationStrength}>{item.strength}</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
            <AlertTriangle size={12} color={Colors.white} />
            <Text style={styles.statusText}>
              {item.status.toUpperCase()}
            </Text>
          </View>
        </View>

        <View style={styles.cardContent}>
          <View style={styles.detailRow}>
            <Calendar size={14} color={Colors.neutral[500]} />
            <Text style={styles.detailText}>
              {getStatusText(item.status, item.daysUntilExpiry)}
            </Text>
          </View>
        </View>

        <View style={styles.cardFooter}>
          <Text style={styles.donorName}>
            Donated by {item.donorName}
          </Text>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );

  const renderMedicationDetail = () => {
    if (!selectedMedication) return null;

    return (
      <Modal
        visible={!!selectedMedication}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.detailContainer} edges={['top', 'right', 'left', 'bottom']}>
          <View style={styles.detailHeader}>
            <Text style={styles.detailTitle}>Expiration Alert</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setSelectedMedication(null)}
            >
              <X size={24} color={Colors.neutral[600]} />
            </TouchableOpacity>
          </View>

          <View style={styles.detailContent}>
            <View style={[
              styles.alertCard,
              { borderColor: getStatusColor(selectedMedication.status) }
            ]}>
              <View style={styles.alertHeader}>
                <AlertTriangle 
                  size={32} 
                  color={getStatusColor(selectedMedication.status)} 
                />
                <View style={styles.alertInfo}>
                  <Text style={styles.alertTitle}>
                    {selectedMedication.status === 'expired' ? 'Medication Expired' : 'Expiration Warning'}
                  </Text>
                  <Text style={[
                    styles.alertSubtitle,
                    { color: getStatusColor(selectedMedication.status) }
                  ]}>
                    {getStatusText(selectedMedication.status, selectedMedication.daysUntilExpiry)}
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.medicationDetails}>
              <Text style={styles.sectionTitle}>Medication Information</Text>
              <View style={styles.detailGrid}>
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Name</Text>
                  <Text style={styles.detailValue}>{selectedMedication.name}</Text>
                </View>
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Strength</Text>
                  <Text style={styles.detailValue}>{selectedMedication.strength}</Text>
                </View>
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Quantity</Text>
                  <Text style={styles.detailValue}>{selectedMedication.quantity}</Text>
                </View>
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Expiry Date</Text>
                  <Text style={styles.detailValue}>{selectedMedication.expiryDate}</Text>
                </View>
              </View>
            </View>

            <View style={styles.pharmacyDetails}>
              <Text style={styles.sectionTitle}>Pharmacy Information</Text>
              <View style={styles.pharmacyCard}>
                <Text style={styles.pharmacyName}>{selectedMedication.pharmacyName}</Text>
                <Text style={styles.pharmacyAddress}>{selectedMedication.pharmacyAddress}</Text>
                <TouchableOpacity style={styles.phoneContainer}>
                  <Phone size={16} color={Colors.primary[500]} />
                  <Text style={styles.phoneNumber}>{selectedMedication.pharmacyPhone}</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.actionButtons}>
              {userRole === 'pharmacist' && (
                <>
                  <TouchableOpacity
                    style={styles.recheckButton}
                    onPress={() => handleRecheckExpiry(selectedMedication.id)}
                  >
                    <RefreshCw size={16} color={Colors.primary[600]} />
                    <Text style={styles.recheckButtonText}>Recheck Expiry</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={styles.removeButton}
                    onPress={() => handleRemoveMedication(selectedMedication.id)}
                  >
                    <Trash2 size={16} color={Colors.white} />
                    <Text style={styles.removeButtonText}>Remove from System</Text>
                  </TouchableOpacity>
                </>
              )}
              
              {userRole === 'donor' && (
                <TouchableOpacity
                  style={styles.contactButton}
                  onPress={() => {
                    Alert.alert(
                      'Contact Pharmacy',
                      `Call ${selectedMedication.pharmacyName} to discuss this medication?`,
                      [
                        { text: 'Cancel', style: 'cancel' },
                        { text: 'Call', onPress: () => {} },
                      ]
                    );
                  }}
                >
                  <Phone size={16} color={Colors.white} />
                  <Text style={styles.contactButtonText}>Contact Pharmacy</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    );
  };

  const getFilterCount = (filterType: string) => {
    if (filterType === 'all') return medications.length;
    return medications.filter(med => med.status === filterType).length;
  };

  return (
    <>
      <Modal
        visible={visible}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Expiration Alerts</Text>
              <Text style={styles.subtitle}>
                {userRole === 'pharmacist' 
                  ? 'Medications requiring attention in your pharmacy'
                  : 'Your donated medications approaching expiry'
                }
              </Text>
            </View>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={onClose}
            >
              <X size={24} color={Colors.neutral[600]} />
            </TouchableOpacity>
          </View>

          <View style={styles.filterContainer}>
            {(['all', 'warning', 'expired'] as const).map((filterType) => (
              <TouchableOpacity
                key={filterType}
                style={[
                  styles.filterButton,
                  filter === filterType && styles.filterButtonActive,
                  filterType === 'expired' && { borderColor: Colors.neutral[300] },
                ]}
                onPress={() => setFilter(filterType)}
              >
                <Text style={[
                  styles.filterButtonText,
                  filter === filterType && styles.filterButtonTextActive,
                ]}>
                  {filterType.charAt(0).toUpperCase() + filterType.slice(1)}
                </Text>
                <View style={[
                  styles.filterBadge,
                  filter === filterType && styles.filterBadgeActive,
                ]}>
                  <Text style={[
                    styles.filterBadgeText,
                    filter === filterType && styles.filterBadgeTextActive,
                  ]}>
                    {getFilterCount(filterType)}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          <FlatList
            data={filteredMedications}
            keyExtractor={(item) => item.id}
            renderItem={renderMedicationCard}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Clock size={48} color={Colors.neutral[300]} />
                <Text style={styles.emptyTitle}>No expiring medications</Text>
                <Text style={styles.emptyText}>
                  {filter === 'all' 
                    ? 'All medications are within safe expiry ranges.'
                    : `No medications in ${filter} status.`
                  }
                </Text>
              </View>
            }
          />
        </SafeAreaView>
      </Modal>
      
      {renderMedicationDetail()}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    marginTop: 4,
    maxWidth: 250,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
    gap: Layout.spacing.sm,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: Layout.spacing.xs,
    borderRadius: Layout.borderRadius.full,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    backgroundColor: Colors.white,
    gap: Layout.spacing.xs,
  },
  filterButtonActive: {
    backgroundColor: Colors.primary[500],
    borderColor: Colors.primary[500],
  },
  filterButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[600],
  },
  filterButtonTextActive: {
    color: Colors.white,
  },
  filterBadge: {
    backgroundColor: Colors.neutral[100],
    borderRadius: Layout.borderRadius.full,
    paddingHorizontal: 6,
    paddingVertical: 2,
    minWidth: 20,
    alignItems: 'center',
  },
  filterBadgeActive: {
    backgroundColor: Colors.primary[400],
  },
  filterBadgeText: {
    fontFamily: 'Inter-Bold',
    fontSize: 12,
    color: Colors.neutral[600],
  },
  filterBadgeTextActive: {
    color: Colors.white,
  },
  listContent: {
    padding: Layout.spacing.lg,
    paddingBottom: Layout.spacing.xxl,
  },
  medicationCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.md,
    marginBottom: Layout.spacing.md,
    borderLeftWidth: 4,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Layout.spacing.sm,
  },
  medicationInfo: {
    flex: 1,
  },
  medicationName: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
  },
  medicationStrength: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: 4,
    borderRadius: Layout.borderRadius.full,
    gap: 4,
  },
  statusText: {
    fontFamily: 'Inter-Bold',
    fontSize: 10,
    color: Colors.white,
    letterSpacing: 0.5,
  },
  cardContent: {
    marginBottom: Layout.spacing.sm,
    gap: 4,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Layout.spacing.xs,
  },
  detailText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    flex: 1,
  },
  cardFooter: {
    paddingTop: Layout.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  donorName: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.primary[600],
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Layout.spacing.xxl * 2,
  },
  emptyTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[600],
    marginTop: Layout.spacing.md,
    marginBottom: Layout.spacing.xs,
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[400],
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: Layout.spacing.xl,
  },
  // Detail Modal Styles
  detailContainer: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  detailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  detailTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  detailContent: {
    flex: 1,
    padding: Layout.spacing.lg,
  },
  alertCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    borderWidth: 2,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Layout.spacing.md,
  },
  alertInfo: {
    flex: 1,
  },
  alertTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
  },
  alertSubtitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    marginTop: 4,
  },
  medicationDetails: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.md,
  },
  detailGrid: {
    gap: Layout.spacing.md,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[500],
  },
  detailValue: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.neutral[800],
  },
  pharmacyDetails: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  pharmacyCard: {
    gap: Layout.spacing.xs,
  },
  pharmacyName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.secondary[700],
  },
  pharmacyAddress: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
  },
  phoneContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[50],
    padding: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    marginTop: Layout.spacing.xs,
    gap: Layout.spacing.xs,
  },
  phoneNumber: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[700],
  },
  actionButtons: {
    gap: Layout.spacing.md,
  },
  recheckButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[50],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  recheckButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.primary[600],
  },
  removeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.error[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  removeButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  contactButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
});