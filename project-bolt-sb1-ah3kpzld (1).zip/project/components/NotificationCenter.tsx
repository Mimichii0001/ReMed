import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { 
  Bell, 
  X, 
  Check, 
  Clock, 
  MapPin, 
  Phone,
  Calendar,
  Package,
  Shield,
  Heart,
  QrCode
} from 'lucide-react-native';
import Animated, { FadeInDown, FadeOutUp } from 'react-native-reanimated';

interface Notification {
  id: string;
  type: 'medication_verified' | 'pickup_reminder' | 'request_approved' | 'donation_success' | 'general';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  medicationName?: string;
  pharmacyName?: string;
  pharmacyAddress?: string;
  pharmacyPhone?: string;
  pickupDeadline?: string;
  actionRequired?: boolean;
  qrCode?: string;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    type: 'medication_verified',
    title: 'Medication Ready for Pickup',
    message: 'Your requested Amoxicillin has been verified and is ready for pickup at MedCare Pharmacy.',
    timestamp: '2 minutes ago',
    read: false,
    medicationName: 'Amoxicillin 500mg',
    pharmacyName: 'MedCare Pharmacy',
    pharmacyAddress: '123 Main St, San Francisco, CA 94102',
    pharmacyPhone: '(415) 555-0123',
    pickupDeadline: 'Pick up by Jan 15, 2025',
    actionRequired: true,
    qrCode: 'MED-AMX-500-2025-001',
  },
  {
    id: '2',
    type: 'donation_success',
    title: 'Thank you! You\'ve helped a soul.',
    message: 'Your medication has been donated successfully!',
    timestamp: '1 hour ago',
    read: false,
    medicationName: 'Metformin 1000mg',
    actionRequired: false,
  },
  {
    id: '3',
    type: 'request_approved',
    title: 'Request Approved',
    message: 'Your request for Lisinopril has been approved by the donor.',
    timestamp: '3 hours ago',
    read: true,
    medicationName: 'Lisinopril 10mg',
    actionRequired: false,
  },
  {
    id: '4',
    type: 'general',
    title: 'New Donations Available',
    message: '5 new verified medications are now available in your area.',
    timestamp: '1 day ago',
    read: true,
    actionRequired: false,
  },
];

interface NotificationCenterProps {
  visible: boolean;
  onClose: () => void;
}

export default function NotificationCenter({ visible, onClose }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, read: true }))
    );
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'medication_verified':
        return <Shield size={20} color={Colors.success[500]} />;
      case 'pickup_reminder':
        return <Clock size={20} color={Colors.warning[500]} />;
      case 'request_approved':
        return <Check size={20} color={Colors.primary[500]} />;
      case 'donation_success':
        return <Heart size={20} color={Colors.accent[500]} />;
      default:
        return <Bell size={20} color={Colors.neutral[500]} />;
    }
  };

  const renderNotificationItem = ({ item }: { item: Notification }) => (
    <Animated.View
      entering={FadeInDown.delay(100)}
      exiting={FadeOutUp}
    >
      <TouchableOpacity
        style={[
          styles.notificationItem,
          !item.read && styles.unreadNotification,
          item.actionRequired && styles.actionRequiredNotification
        ]}
        onPress={() => {
          markAsRead(item.id);
          setSelectedNotification(item);
        }}
      >
        <View style={styles.notificationIcon}>
          {getNotificationIcon(item.type)}
        </View>
        
        <View style={styles.notificationContent}>
          <View style={styles.notificationHeader}>
            <Text style={[
              styles.notificationTitle,
              !item.read && styles.unreadTitle
            ]}>
              {item.title}
            </Text>
            <Text style={styles.notificationTime}>{item.timestamp}</Text>
          </View>
          
          {/* QR Code Section for medication ready notifications - moved up */}
          {item.type === 'medication_verified' && item.qrCode && (
            <View style={styles.inlineQrSection}>
              <View style={styles.inlineQrCode}>
                <QrCode size={40} color={Colors.neutral[800]} />
                <View style={styles.inlineQrInfo}>
                  <Text style={styles.inlineQrCodeText}>{item.qrCode}</Text>
                  <Text style={styles.inlineInstructionText}>
                    Show this to the pharmacist to receive your medication
                  </Text>
                </View>
              </View>
            </View>
          )}
          
          {item.actionRequired && !item.qrCode && (
            <View style={styles.actionBadge}>
              <Text style={styles.actionBadgeText}>Action Required</Text>
            </View>
          )}
        </View>
        
        {!item.read && <View style={styles.unreadDot} />}
      </TouchableOpacity>
    </Animated.View>
  );

  const renderNotificationDetail = () => {
    if (!selectedNotification) return null;

    return (
      <Modal
        visible={!!selectedNotification}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.detailContainer} edges={['top', 'right', 'left', 'bottom']}>
          <View style={styles.detailHeader}>
            <Text style={styles.detailTitle}>Notification Details</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setSelectedNotification(null)}
            >
              <X size={24} color={Colors.neutral[600]} />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.detailContent}>
            <View style={styles.detailCard}>
              <View style={styles.detailIconContainer}>
                {getNotificationIcon(selectedNotification.type)}
              </View>
              
              <Text style={styles.detailNotificationTitle}>
                {selectedNotification.title}
              </Text>
              
              <Text style={styles.detailTimestamp}>
                {selectedNotification.timestamp}
              </Text>
            </View>
            
            {selectedNotification.qrCode && (
              <View style={styles.qrCodeCard}>
                <View style={styles.qrCodeHeader}>
                  <QrCode size={20} color={Colors.primary[500]} />
                  <Text style={styles.qrCodeTitle}>Pickup Code</Text>
                </View>
                
                <View style={styles.qrCodeContainer}>
                  <View style={styles.qrCodePlaceholder}>
                    <QrCode size={80} color={Colors.neutral[800]} />
                  </View>
                  <Text style={styles.qrCodeText}>{selectedNotification.qrCode}</Text>
                </View>
                
                <View style={styles.instructionContainer}>
                  <Text style={styles.instructionText}>
                    Show this to the pharmacist to receive your medication
                  </Text>
                </View>
              </View>
            )}
            
            {selectedNotification.medicationName && (
              <View style={styles.medicationCard}>
                <View style={styles.medicationHeader}>
                  <Package size={20} color={Colors.primary[500]} />
                  <Text style={styles.medicationTitle}>Medication Details</Text>
                </View>
                
                <Text style={styles.medicationName}>
                  {selectedNotification.medicationName}
                </Text>
                
                {selectedNotification.pickupDeadline && (
                  <View style={styles.deadlineContainer}>
                    <Calendar size={16} color={Colors.warning[500]} />
                    <Text style={styles.deadlineText}>
                      {selectedNotification.pickupDeadline}
                    </Text>
                  </View>
                )}
              </View>
            )}
            
            {selectedNotification.pharmacyName && (
              <View style={styles.pharmacyCard}>
                <View style={styles.pharmacyHeader}>
                  <MapPin size={20} color={Colors.secondary[500]} />
                  <Text style={styles.pharmacyTitle}>Pharmacy Information</Text>
                </View>
                
                <Text style={styles.pharmacyName}>
                  {selectedNotification.pharmacyName}
                </Text>
                
                {selectedNotification.pharmacyAddress && (
                  <Text style={styles.pharmacyAddress}>
                    {selectedNotification.pharmacyAddress}
                  </Text>
                )}
                
                {selectedNotification.pharmacyPhone && (
                  <TouchableOpacity style={styles.phoneContainer}>
                    <Phone size={16} color={Colors.primary[500]} />
                    <Text style={styles.phoneNumber}>
                      {selectedNotification.pharmacyPhone}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
            
            {selectedNotification.actionRequired && (
              <View style={styles.actionsContainer}>
                <TouchableOpacity style={styles.primaryAction}>
                  <MapPin size={16} color={Colors.white} />
                  <Text style={styles.primaryActionText}>Get Directions</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.secondaryAction}>
                  <Phone size={16} color={Colors.primary[600]} />
                  <Text style={styles.secondaryActionText}>Call Pharmacy</Text>
                </TouchableOpacity>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>
    );
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <>
      <Modal
        visible={visible}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Notifications</Text>
              {unreadCount > 0 && (
                <Text style={styles.unreadCount}>
                  {unreadCount} unread
                </Text>
              )}
            </View>
            
            <View style={styles.headerActions}>
              {unreadCount > 0 && (
                <TouchableOpacity
                  style={styles.markAllButton}
                  onPress={markAllAsRead}
                >
                  <Text style={styles.markAllText}>Mark all read</Text>
                </TouchableOpacity>
              )}
              
              <TouchableOpacity
                style={styles.closeButton}
                onPress={onClose}
              >
                <X size={24} color={Colors.neutral[600]} />
              </TouchableOpacity>
            </View>
          </View>
          
          <FlatList
            data={notifications}
            keyExtractor={(item) => item.id}
            renderItem={renderNotificationItem}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Bell size={48} color={Colors.neutral[300]} />
                <Text style={styles.emptyTitle}>No notifications</Text>
                <Text style={styles.emptyText}>
                  You're all caught up! We'll notify you when there are updates.
                </Text>
              </View>
            }
          />
        </SafeAreaView>
      </Modal>
      
      {renderNotificationDetail()}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
  },
  unreadCount: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[600],
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Layout.spacing.sm,
  },
  markAllButton: {
    paddingVertical: Layout.spacing.xs,
    paddingHorizontal: Layout.spacing.sm,
  },
  markAllText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[600],
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: {
    padding: Layout.spacing.lg,
    paddingBottom: Layout.spacing.xxl,
  },
  notificationItem: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.md,
    marginBottom: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  unreadNotification: {
    borderLeftWidth: 4,
    borderLeftColor: Colors.primary[500],
  },
  actionRequiredNotification: {
    borderWidth: 1,
    borderColor: Colors.warning[200],
    backgroundColor: Colors.warning[25],
  },
  notificationIcon: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.md,
  },
  notificationContent: {
    flex: 1,
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Layout.spacing.xs,
  },
  notificationTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    flex: 1,
    marginRight: Layout.spacing.sm,
  },
  unreadTitle: {
    fontFamily: 'Inter-Bold',
  },
  notificationTime: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[500],
  },
  inlineQrSection: {
    backgroundColor: Colors.primary[25],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.sm,
    marginTop: Layout.spacing.xs,
    borderWidth: 1,
    borderColor: Colors.primary[100],
  },
  inlineQrCode: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Layout.spacing.sm,
  },
  inlineQrInfo: {
    flex: 1,
  },
  inlineQrCodeText: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: Colors.primary[800],
    marginBottom: 2,
  },
  inlineInstructionText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.primary[700],
    lineHeight: 16,
  },
  actionBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.warning[100],
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: 4,
    borderRadius: Layout.borderRadius.full,
  },
  actionBadgeText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.warning[700],
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[500],
    marginTop: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Layout.spacing.xxl * 2,
  },
  emptyTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[600],
    marginTop: Layout.spacing.md,
    marginBottom: Layout.spacing.xs,
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[400],
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: Layout.spacing.xl,
  },
  // Detail Modal Styles
  detailContainer: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  detailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  detailTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  detailContent: {
    flex: 1,
    padding: Layout.spacing.lg,
  },
  detailCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  detailIconContainer: {
    width: 60,
    height: 60,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.md,
  },
  detailNotificationTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    textAlign: 'center',
    marginBottom: Layout.spacing.md,
  },
  detailTimestamp: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[500],
  },
  qrCodeCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  qrCodeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.lg,
  },
  qrCodeTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  qrCodeContainer: {
    alignItems: 'center',
    marginBottom: Layout.spacing.lg,
  },
  qrCodePlaceholder: {
    width: 120,
    height: 120,
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.md,
    borderWidth: 2,
    borderColor: Colors.neutral[200],
    borderStyle: 'dashed',
  },
  qrCodeText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.neutral[800],
    letterSpacing: 1,
  },
  instructionContainer: {
    backgroundColor: Colors.primary[50],
    padding: Layout.spacing.md,
    borderRadius: Layout.borderRadius.md,
    borderWidth: 1,
    borderColor: Colors.primary[200],
  },
  instructionText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.primary[700],
    textAlign: 'center',
  },
  medicationCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  medicationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  medicationTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  medicationName: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.primary[700],
    marginBottom: Layout.spacing.sm,
  },
  deadlineContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.warning[50],
    padding: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
  },
  deadlineText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.warning[700],
    marginLeft: Layout.spacing.xs,
  },
  pharmacyCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  pharmacyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  pharmacyTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  pharmacyName: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.secondary[700],
    marginBottom: Layout.spacing.xs,
  },
  pharmacyAddress: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
    marginBottom: Layout.spacing.sm,
  },
  phoneContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[50],
    padding: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
  },
  phoneNumber: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[700],
    marginLeft: Layout.spacing.xs,
  },
  actionsContainer: {
    gap: Layout.spacing.md,
  },
  primaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  primaryActionText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  secondaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[50],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  secondaryActionText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.primary[600],
  },
});