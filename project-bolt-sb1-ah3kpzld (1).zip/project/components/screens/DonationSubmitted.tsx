import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { useRouter } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function DonationSubmitted() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
      <Animated.View 
        style={styles.content}
        entering={FadeInDown.delay(200).springify()}
      >
        <Image
          source={{ uri: "https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" }}
          style={styles.image}
        />
        
        <Text style={styles.title}>Thank You for Your Donation!</Text>
        
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>What happens next?</Text>
          <Text style={styles.infoText}>
            A licensed pharmacist will verify your donation submission before it becomes available for redistribution.
          </Text>
          
          <View style={styles.statusContainer}>
            <View style={styles.statusStep}>
              <View style={[styles.statusDot, styles.statusDotActive]}>
                <View style={styles.statusDotInner} />
              </View>
              <Text style={styles.statusText}>Submitted</Text>
            </View>
            <View style={[styles.statusLine, styles.statusLineInactive]} />
            <View style={styles.statusStep}>
              <View style={[styles.statusDot, styles.statusDotInactive]} />
              <Text style={[styles.statusText, styles.statusTextInactive]}>In Review</Text>
            </View>
            <View style={[styles.statusLine, styles.statusLineInactive]} />
            <View style={styles.statusStep}>
              <View style={[styles.statusDot, styles.statusDotInactive]} />
              <Text style={[styles.statusText, styles.statusTextInactive]}>Verified</Text>
            </View>
          </View>
          
          <Text style={styles.estimatedTime}>
            Estimated review time: 24-48 hours
          </Text>
        </View>
        
        <Text style={styles.notification}>
          We'll notify you once your donation is verified.
        </Text>
        
        <TouchableOpacity 
          style={styles.button}
          onPress={() => router.replace('/')}
        >
          <Text style={styles.buttonText}>Return to Home</Text>
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.xl,
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: Layout.borderRadius.full,
    marginBottom: Layout.spacing.xl,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    textAlign: 'center',
    marginBottom: Layout.spacing.lg,
  },
  infoCard: {
    backgroundColor: Colors.primary[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    width: '100%',
    marginBottom: Layout.spacing.lg,
  },
  infoTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.primary[700],
    marginBottom: Layout.spacing.sm,
  },
  infoText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.primary[800],
    lineHeight: 24,
    marginBottom: Layout.spacing.lg,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Layout.spacing.lg,
  },
  statusStep: {
    alignItems: 'center',
  },
  statusDot: {
    width: 24,
    height: 24,
    borderRadius: Layout.borderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statusDotActive: {
    backgroundColor: Colors.primary[200],
  },
  statusDotInactive: {
    backgroundColor: Colors.neutral[200],
  },
  statusDotInner: {
    width: 12,
    height: 12,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[600],
  },
  statusText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[700],
  },
  statusTextInactive: {
    color: Colors.neutral[400],
  },
  statusLine: {
    height: 2,
    flex: 1,
    marginHorizontal: 4,
  },
  statusLineActive: {
    backgroundColor: Colors.primary[500],
  },
  statusLineInactive: {
    backgroundColor: Colors.neutral[200],
  },
  estimatedTime: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[700],
    textAlign: 'center',
  },
  notification: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[500],
    marginBottom: Layout.spacing.xxl,
    textAlign: 'center',
  },
  button: {
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    paddingHorizontal: Layout.spacing.xl,
    borderRadius: Layout.borderRadius.md,
  },
  buttonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
});