import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  ScrollView,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { X, Bell, ChevronRight, User, Shield, CircleHelp as HelpCircle, MessageSquare } from 'lucide-react-native';
import FeedbackForm from './FeedbackForm';

interface AccountSettingsProps {
  visible: boolean;
  onClose: () => void;
}

export default function AccountSettings({ visible, onClose }: AccountSettingsProps) {
  const [pushNotifications, setPushNotifications] = useState(true);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);

  return (
    <>
      <Modal
        visible={visible}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
          <View style={styles.header}>
            <Text style={styles.title}>Settings</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={onClose}
            >
              <X size={24} color={Colors.neutral[600]} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {/* Notifications Section */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Notifications</Text>
              
              <View style={styles.settingItem}>
                <View style={styles.settingInfo}>
                  <View style={styles.settingHeader}>
                    <Bell size={20} color={Colors.primary[500]} />
                    <Text style={styles.settingTitle}>Push Notifications</Text>
                  </View>
                  <Text style={styles.settingDescription}>
                    Receive notifications on your device for medication updates and reminders
                  </Text>
                </View>
                <Switch
                  value={pushNotifications}
                  onValueChange={setPushNotifications}
                  trackColor={{ false: Colors.neutral[200], true: Colors.primary[200] }}
                  thumbColor={pushNotifications ? Colors.primary[500] : Colors.neutral[400]}
                />
              </View>
            </View>

            {/* Account Section */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Account</Text>
              
              <TouchableOpacity style={styles.menuItem}>
                <View style={styles.menuItemContent}>
                  <User size={20} color={Colors.neutral[600]} />
                  <Text style={styles.menuItemText}>Personal Information</Text>
                </View>
                <ChevronRight size={20} color={Colors.neutral[400]} />
              </TouchableOpacity>

              <TouchableOpacity style={styles.menuItem}>
                <View style={styles.menuItemContent}>
                  <Shield size={20} color={Colors.neutral[600]} />
                  <Text style={styles.menuItemText}>Privacy Settings</Text>
                </View>
                <ChevronRight size={20} color={Colors.neutral[400]} />
              </TouchableOpacity>
            </View>

            {/* Support Section */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Support</Text>
              
              <TouchableOpacity style={styles.menuItem}>
                <View style={styles.menuItemContent}>
                  <HelpCircle size={20} color={Colors.neutral[600]} />
                  <Text style={styles.menuItemText}>Help & Support</Text>
                </View>
                <ChevronRight size={20} color={Colors.neutral[400]} />
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.menuItem, { borderBottomWidth: 0 }]}
                onPress={() => setShowFeedbackForm(true)}
              >
                <View style={styles.menuItemContent}>
                  <MessageSquare size={20} color={Colors.primary[500]} />
                  <Text style={styles.menuItemText}>Share Feedback</Text>
                </View>
                <ChevronRight size={20} color={Colors.neutral[400]} />
              </TouchableOpacity>
            </View>

            <View style={styles.bottomSpacer} />
          </ScrollView>
        </SafeAreaView>
      </Modal>

      <FeedbackForm
        visible={showFeedbackForm}
        onClose={() => setShowFeedbackForm(false)}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: Colors.white,
    marginTop: Layout.spacing.lg,
    paddingVertical: Layout.spacing.lg,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    paddingHorizontal: Layout.spacing.lg,
    marginBottom: Layout.spacing.md,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
  },
  settingInfo: {
    flex: 1,
    marginRight: Layout.spacing.md,
  },
  settingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.xs,
  },
  settingTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  settingDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    lineHeight: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[800],
    marginLeft: Layout.spacing.sm,
  },
  bottomSpacer: {
    height: Layout.spacing.xxl,
  },
});