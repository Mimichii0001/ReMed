import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Modal,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { X, MessageSquare, Star, Send, User, Mail } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

interface FeedbackFormProps {
  visible: boolean;
  onClose: () => void;
}

interface FeedbackData {
  name: string;
  email: string;
  category: string;
  rating: number;
  feedback: string;
}

const FEEDBACK_CATEGORIES = [
  'App Performance',
  'User Experience',
  'Feature Request',
  'Bug Report',
  'General Feedback',
  'Other'
];

export default function FeedbackForm({ visible, onClose }: FeedbackFormProps) {
  const [formData, setFormData] = useState<FeedbackData>({
    name: '',
    email: '',
    category: '',
    rating: 0,
    feedback: '',
  });
  const [hoveredStar, setHoveredStar] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleStarPress = (starRating: number) => {
    setFormData(prev => ({ ...prev, rating: starRating }));
  };

  const handleSubmit = async () => {
    // Validate required fields
    if (!formData.name.trim() || !formData.email.trim() || !formData.feedback.trim()) {
      Alert.alert('Required Fields', 'Please fill in your name, email, and feedback.');
      return;
    }

    if (!formData.email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address.');
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      Alert.alert(
        'Thank You!',
        'Your feedback has been submitted successfully. We appreciate your input and will review it carefully.',
        [
          {
            text: 'OK',
            onPress: () => {
              // Reset form
              setFormData({
                name: '',
                email: '',
                category: '',
                rating: 0,
                feedback: '',
              });
              onClose();
            },
          },
        ]
      );
    }, 2000);
  };

  const getRatingText = (stars: number) => {
    switch (stars) {
      case 1: return 'Poor';
      case 2: return 'Fair';
      case 3: return 'Good';
      case 4: return 'Very Good';
      case 5: return 'Excellent';
      default: return 'Rate your experience';
    }
  };

  const isFormValid = formData.name.trim() && formData.email.trim() && formData.feedback.trim();

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
        <View style={styles.header}>
          <Text style={styles.title}>Share Your Feedback</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={onClose}
          >
            <X size={24} color={Colors.neutral[600]} />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          <Animated.View 
            style={styles.introSection}
            entering={FadeInDown.delay(100).springify()}
          >
            <View style={styles.introIcon}>
              <MessageSquare size={24} color={Colors.primary[500]} />
            </View>
            <Text style={styles.introTitle}>We Value Your Opinion</Text>
            <Text style={styles.introText}>
              Help us improve ReMed by sharing your thoughts and suggestions.
            </Text>
          </Animated.View>

          <Animated.View 
            style={styles.formSection}
            entering={FadeInDown.delay(200).springify()}
          >
            {/* Personal Information */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Name *</Text>
              <View style={styles.inputContainer}>
                <User size={20} color={Colors.neutral[400]} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="Your full name"
                  value={formData.name}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, name: text }))}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email *</Text>
              <View style={styles.inputContainer}>
                <Mail size={20} color={Colors.neutral[400]} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, email: text }))}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
            </View>

            {/* Category Selection */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Category</Text>
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                style={styles.categoryScroll}
              >
                {FEEDBACK_CATEGORIES.map((category) => (
                  <TouchableOpacity
                    key={category}
                    style={[
                      styles.categoryButton,
                      formData.category === category && styles.categoryButtonSelected
                    ]}
                    onPress={() => setFormData(prev => ({ ...prev, category }))}
                  >
                    <Text style={[
                      styles.categoryButtonText,
                      formData.category === category && styles.categoryButtonTextSelected
                    ]}>
                      {category}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>

            {/* Rating */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Overall Rating</Text>
              <View style={styles.ratingContainer}>
                <View style={styles.starsContainer}>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <TouchableOpacity
                      key={star}
                      style={styles.starButton}
                      onPress={() => handleStarPress(star)}
                      onPressIn={() => setHoveredStar(star)}
                      onPressOut={() => setHoveredStar(0)}
                    >
                      <Star
                        size={32}
                        color={
                          star <= (hoveredStar || formData.rating)
                            ? Colors.warning[500]
                            : Colors.neutral[300]
                        }
                        fill={
                          star <= (hoveredStar || formData.rating)
                            ? Colors.warning[500]
                            : 'transparent'
                        }
                      />
                    </TouchableOpacity>
                  ))}
                </View>
                <Text style={styles.ratingText}>
                  {getRatingText(formData.rating)}
                </Text>
              </View>
            </View>

            {/* Feedback Text */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Your Feedback *</Text>
              <View style={[styles.inputContainer, styles.textAreaContainer]}>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Share your thoughts, suggestions, or report any issues..."
                  value={formData.feedback}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, feedback: text }))}
                  multiline
                  numberOfLines={6}
                  textAlignVertical="top"
                  maxLength={1000}
                />
              </View>
              <Text style={styles.characterCount}>
                {formData.feedback.length}/1000 characters
              </Text>
            </View>
          </Animated.View>

          <View style={styles.bottomSpacer} />
        </ScrollView>

        <View style={styles.footer}>
          <TouchableOpacity
            style={[
              styles.submitButton,
              (!isFormValid || isSubmitting) && styles.submitButtonDisabled
            ]}
            onPress={handleSubmit}
            disabled={!isFormValid || isSubmitting}
          >
            {isSubmitting ? (
              <Text style={styles.submitButtonText}>Submitting...</Text>
            ) : (
              <>
                <Send size={16} color={Colors.white} />
                <Text style={styles.submitButtonText}>Submit Feedback</Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    padding: Layout.spacing.lg,
  },
  introSection: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    marginBottom: Layout.spacing.lg,
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  introIcon: {
    width: 60,
    height: 60,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.md,
  },
  introTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  introText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[600],
    textAlign: 'center',
    lineHeight: 24,
  },
  formSection: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  inputGroup: {
    marginBottom: Layout.spacing.lg,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[700],
    marginBottom: Layout.spacing.xs,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.neutral[50],
    paddingHorizontal: Layout.spacing.sm,
  },
  inputIcon: {
    marginRight: Layout.spacing.xs,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
    paddingVertical: Layout.spacing.sm,
  },
  textAreaContainer: {
    alignItems: 'flex-start',
    minHeight: 120,
  },
  textArea: {
    paddingTop: Layout.spacing.sm,
    height: 100,
  },
  characterCount: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[400],
    textAlign: 'right',
    marginTop: Layout.spacing.xs,
  },
  categoryScroll: {
    marginHorizontal: -Layout.spacing.sm,
  },
  categoryButton: {
    backgroundColor: Colors.neutral[100],
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.full,
    marginHorizontal: Layout.spacing.xs,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
  },
  categoryButtonSelected: {
    backgroundColor: Colors.primary[500],
    borderColor: Colors.primary[500],
  },
  categoryButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[600],
  },
  categoryButtonTextSelected: {
    color: Colors.white,
  },
  ratingContainer: {
    alignItems: 'center',
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
  },
  starsContainer: {
    flexDirection: 'row',
    gap: Layout.spacing.xs,
    marginBottom: Layout.spacing.sm,
  },
  starButton: {
    padding: Layout.spacing.xs,
  },
  ratingText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[600],
  },
  footer: {
    padding: Layout.spacing.lg,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  submitButtonDisabled: {
    backgroundColor: Colors.neutral[300],
  },
  submitButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
  bottomSpacer: {
    height: Layout.spacing.xl,
  },
});