export interface Medicine {
  id: string;
  name: string;
  type: string;
  expiryDate: string;
  distance: string;
  quantity: string;
  strength: string;
  imageUrl: string;
  donorName: string;
  verificationDate: string;
  pharmacy: Pharmacy;
}

export interface Pharmacy {
  id: string;
  name: string;
  address: string;
  distance: string;
  phone: string;
  hours: string;
  rating: number;
  reviewCount: number;
  imageUrl: string;
  logoUrl: string;
  verified: boolean;
  specialties: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  location: string;
  role: 'donor' | 'pharmacist' | 'admin';
  profileImageUrl?: string;
}

export interface Donation {
  id: string;
  medicineId: string;
  donorId: string;
  status: 'pending' | 'verified' | 'rejected';
  submissionDate: string;
  verificationDate?: string;
  verifiedBy?: string;
}