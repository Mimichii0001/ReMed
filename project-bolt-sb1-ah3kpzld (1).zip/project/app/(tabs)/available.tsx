import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Filter, Search, Bell, CircleCheck as CheckCircle, X, MapPin } from 'lucide-react-native';
import MedicineCard from '@/components/MedicineCard';
import { Medicine, Pharmacy } from '@/types';
import Animated, { FadeInDown, FadeOutUp } from 'react-native-reanimated';

interface FilterOptions {
  medicationType: string[];
  distance: string;
  expiryDate: string;
  verificationStatus: string;
  nearbyPharmacy: string[];
}

// Mock pharmacies data
const MOCK_PHARMACIES: Pharmacy[] = [
  {
    id: '1',
    name: 'MedCare Pharmacy',
    address: '123 Main St, San Francisco, CA 94102',
    distance: '0.3',
    phone: '(415) 555-0123',
    hours: 'Open until 9:00 PM',
    rating: 4.8,
    reviewCount: 127,
    imageUrl: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['Prescription Filling', 'Medication Counseling', 'Immunizations']
  },
  {
    id: '2',
    name: 'Community Health Pharmacy',
    address: '456 Oak Ave, San Francisco, CA 94103',
    distance: '0.7',
    phone: '(415) 555-0456',
    hours: 'Open until 8:00 PM',
    rating: 4.6,
    reviewCount: 89,
    imageUrl: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['Compounding', 'Diabetes Care', 'Blood Pressure Monitoring']
  },
  {
    id: '3',
    name: 'Wellness Pharmacy Plus',
    address: '789 Pine St, San Francisco, CA 94108',
    distance: '1.2',
    phone: '(415) 555-0789',
    hours: 'Open until 10:00 PM',
    rating: 4.9,
    reviewCount: 203,
    imageUrl: 'https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['24/7 Service', 'Emergency Prescriptions', 'Home Delivery']
  },
  {
    id: '4',
    name: 'Bay Area Pharmacy',
    address: '321 Market St, San Francisco, CA 94105',
    distance: '1.8',
    phone: '(415) 555-0321',
    hours: 'Open until 7:00 PM',
    rating: 4.4,
    reviewCount: 156,
    imageUrl: 'https://images.pexels.com/photos/5327580/pexels-photo-5327580.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['Insurance Processing', 'Generic Alternatives', 'Medication Sync']
  },
  {
    id: '5',
    name: 'HealthFirst Pharmacy',
    address: '654 Mission St, San Francisco, CA 94104',
    distance: '2.1',
    phone: '(415) 555-0654',
    hours: 'Closes at 6:00 PM',
    rating: 4.7,
    reviewCount: 92,
    imageUrl: 'https://images.pexels.com/photos/5327647/pexels-photo-5327647.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/5327580/pexels-photo-5327580.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['Specialty Medications', 'Clinical Services', 'Health Screenings']
  }
];

// Mock data for available medicines with pharmacy information
const MOCK_MEDICINES: Medicine[] = [
  {
    id: '1',
    name: 'Amoxicillin',
    type: 'Antibiotic',
    expiryDate: 'Jan 2025',
    distance: '2.3',
    quantity: '30 tablets',
    strength: '500mg',
    imageUrl: 'https://images.pexels.com/photos/139398/himalayas-mountains-nepal-hill-139398.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'John D.',
    verificationDate: '2 days ago',
    pharmacy: MOCK_PHARMACIES[0],
  },
  {
    id: '2',
    name: 'Metformin',
    type: 'Diabetes',
    expiryDate: 'Dec 2024',
    distance: '0.8',
    quantity: '60 tablets',
    strength: '1000mg',
    imageUrl: 'https://images.pexels.com/photos/208512/pexels-photo-208512.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Sarah M.',
    verificationDate: '5 days ago',
    pharmacy: MOCK_PHARMACIES[1],
  },
  {
    id: '3',
    name: 'Lisinopril',
    type: 'Blood Pressure',
    expiryDate: 'Mar 2025',
    distance: '3.5',
    quantity: '45 tablets',
    strength: '10mg',
    imageUrl: 'https://images.pexels.com/photos/669621/pexels-photo-669621.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Emily K.',
    verificationDate: '1 day ago',
    pharmacy: MOCK_PHARMACIES[2],
  },
  {
    id: '4',
    name: 'Atorvastatin',
    type: 'Cholesterol',
    expiryDate: 'Feb 2025',
    distance: '1.5',
    quantity: '30 tablets',
    strength: '20mg',
    imageUrl: 'https://images.pexels.com/photos/2089799/pexels-photo-2089799.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Robert J.',
    verificationDate: '3 days ago',
    pharmacy: MOCK_PHARMACIES[3],
  },
  {
    id: '5',
    name: 'Levothyroxine',
    type: 'Thyroid',
    expiryDate: 'Nov 2024',
    distance: '4.2',
    quantity: '90 tablets',
    strength: '50mcg',
    imageUrl: 'https://images.pexels.com/photos/1089438/pexels-photo-1089438.jpeg?auto=compress&cs=tinysrgb&w=800',
    donorName: 'Patricia L.',
    verificationDate: '1 week ago',
    pharmacy: MOCK_PHARMACIES[4],
  },
];

export default function AvailableScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [medicines, setMedicines] = useState(MOCK_MEDICINES);
  const [showRequestPopup, setShowRequestPopup] = useState(false);
  const [requestedMedicine, setRequestedMedicine] = useState<Medicine | null>(null);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    medicationType: [],
    distance: 'all',
    expiryDate: 'all',
    verificationStatus: 'all',
    nearbyPharmacy: []
  });
  
  // Filter medicines based on search query and filters
  const filteredMedicines = medicines.filter(medicine => {
    // Search filter
    const matchesSearch = medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      medicine.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      medicine.pharmacy.name.toLowerCase().includes(searchQuery.toLowerCase());

    // Type filter
    const matchesType = filters.medicationType.length === 0 ||
      filters.medicationType.includes(medicine.type);

    // Distance filter
    const distanceValue = parseFloat(medicine.distance);
    const matchesDistance = filters.distance === 'all' ||
      (filters.distance === '1' && distanceValue <= 1) ||
      (filters.distance === '2' && distanceValue <= 2) ||
      (filters.distance === '5' && distanceValue <= 5);

    // Expiry date filter
    const matchesExpiry = filters.expiryDate === 'all' ||
      (filters.expiryDate === '3_months' && medicine.expiryDate.includes('2024')) ||
      (filters.expiryDate === '6_months' && (medicine.expiryDate.includes('2024') || medicine.expiryDate.includes('Jan 2025') || medicine.expiryDate.includes('Feb 2025'))) ||
      (filters.expiryDate === '1_year' && true); // All medicines in our mock data are within a year

    // Verification status filter
    const verificationDays = parseInt(medicine.verificationDate.split(' ')[0]);
    const matchesVerification = filters.verificationStatus === 'all' ||
      (filters.verificationStatus === 'recent' && verificationDays <= 3) ||
      (filters.verificationStatus === 'week' && verificationDays <= 7);

    // Nearby pharmacy filter
    const matchesPharmacy = filters.nearbyPharmacy.length === 0 ||
      filters.nearbyPharmacy.includes(medicine.pharmacy.id);

    return matchesSearch && matchesType && matchesDistance && matchesExpiry && matchesVerification && matchesPharmacy;
  });

  const handleMedicineRequest = (medicine: Medicine) => {
    setRequestedMedicine(medicine);
    setShowRequestPopup(true);
  };

  const closeRequestPopup = () => {
    setShowRequestPopup(false);
    setRequestedMedicine(null);
  };

  const applyFilters = (newFilters: FilterOptions) => {
    setFilters(newFilters);
    setShowFilterModal(false);
  };

  const clearFilters = () => {
    setFilters({
      medicationType: [],
      distance: 'all',
      expiryDate: 'all',
      verificationStatus: 'all',
      nearbyPharmacy: []
    });
  };

  const FilterModal = () => {
    const [tempFilters, setTempFilters] = useState(filters);

    const medicationTypes = ['Antibiotic', 'Diabetes', 'Blood Pressure', 'Cholesterol', 'Thyroid', 'Pain Relief', 'Heart', 'Mental Health'];

    const toggleMedicationType = (type: string) => {
      setTempFilters(prev => ({
        ...prev,
        medicationType: prev.medicationType.includes(type)
          ? prev.medicationType.filter(t => t !== type)
          : [...prev.medicationType, type]
      }));
    };

    const toggleNearbyPharmacy = (pharmacyId: string) => {
      setTempFilters(prev => ({
        ...prev,
        nearbyPharmacy: prev.nearbyPharmacy.includes(pharmacyId)
          ? prev.nearbyPharmacy.filter(id => id !== pharmacyId)
          : [...prev.nearbyPharmacy, pharmacyId]
      }));
    };

    return (
      <Modal
        visible={showFilterModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.filterModalContainer} edges={['top', 'right', 'left', 'bottom']}>
          <View style={styles.filterHeader}>
            <Text style={styles.filterTitle}>Filter Medications</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setShowFilterModal(false)}
            >
              <X size={24} color={Colors.neutral[600]} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.filterContent}>
            {/* Nearby Pharmacy Filter */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Nearby Pharmacies</Text>
              <View style={styles.pharmacyGrid}>
                {MOCK_PHARMACIES.map((pharmacy) => (
                  <TouchableOpacity
                    key={pharmacy.id}
                    style={[
                      styles.pharmacyFilterOption,
                      tempFilters.nearbyPharmacy.includes(pharmacy.id) && styles.pharmacyFilterOptionSelected
                    ]}
                    onPress={() => toggleNearbyPharmacy(pharmacy.id)}
                  >
                    <View style={styles.pharmacyFilterContent}>
                      <Text style={[
                        styles.pharmacyFilterName,
                        tempFilters.nearbyPharmacy.includes(pharmacy.id) && styles.pharmacyFilterNameSelected
                      ]}>
                        {pharmacy.name}
                      </Text>
                      <View style={styles.pharmacyFilterDetails}>
                        <MapPin size={12} color={tempFilters.nearbyPharmacy.includes(pharmacy.id) ? Colors.white : Colors.neutral[500]} />
                        <Text style={[
                          styles.pharmacyFilterDistance,
                          tempFilters.nearbyPharmacy.includes(pharmacy.id) && styles.pharmacyFilterDistanceSelected
                        ]}>
                          {pharmacy.distance} miles
                        </Text>
                      </View>
                    </View>
                    {tempFilters.nearbyPharmacy.includes(pharmacy.id) && (
                      <CheckCircle size={16} color={Colors.white} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Medication Type Filter */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Medication Type</Text>
              <View style={styles.typeGrid}>
                {medicationTypes.map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[
                      styles.typeFilterOption,
                      tempFilters.medicationType.includes(type) && styles.typeFilterOptionSelected
                    ]}
                    onPress={() => toggleMedicationType(type)}
                  >
                    <Text style={[
                      styles.typeFilterText,
                      tempFilters.medicationType.includes(type) && styles.typeFilterTextSelected
                    ]}>
                      {type}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Distance Filter */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Distance</Text>
              <View style={styles.filterOptions}>
                {[
                  { value: 'all', label: 'Any distance' },
                  { value: '1', label: 'Within 1 mile' },
                  { value: '2', label: 'Within 2 miles' },
                  { value: '5', label: 'Within 5 miles' }
                ].map((option) => (
                  <TouchableOpacity
                    key={option.value}
                    style={[
                      styles.filterOption,
                      tempFilters.distance === option.value && styles.filterOptionSelected
                    ]}
                    onPress={() => setTempFilters(prev => ({ ...prev, distance: option.value }))}
                  >
                    <Text style={[
                      styles.filterOptionText,
                      tempFilters.distance === option.value && styles.filterOptionTextSelected
                    ]}>
                      {option.label}
                    </Text>
                    {tempFilters.distance === option.value && (
                      <CheckCircle size={16} color={Colors.primary[500]} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Expiry Date Filter */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Expiry Date</Text>
              <View style={styles.filterOptions}>
                {[
                  { value: 'all', label: 'Any expiry date' },
                  { value: '3_months', label: 'Within 3 months' },
                  { value: '6_months', label: 'Within 6 months' },
                  { value: '1_year', label: 'Within 1 year' }
                ].map((option) => (
                  <TouchableOpacity
                    key={option.value}
                    style={[
                      styles.filterOption,
                      tempFilters.expiryDate === option.value && styles.filterOptionSelected
                    ]}
                    onPress={() => setTempFilters(prev => ({ ...prev, expiryDate: option.value }))}
                  >
                    <Text style={[
                      styles.filterOptionText,
                      tempFilters.expiryDate === option.value && styles.filterOptionTextSelected
                    ]}>
                      {option.label}
                    </Text>
                    {tempFilters.expiryDate === option.value && (
                      <CheckCircle size={16} color={Colors.primary[500]} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Verification Status Filter */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Verification Status</Text>
              <View style={styles.filterOptions}>
                {[
                  { value: 'all', label: 'All verified' },
                  { value: 'recent', label: 'Recently verified (3 days)' },
                  { value: 'week', label: 'Verified this week' }
                ].map((option) => (
                  <TouchableOpacity
                    key={option.value}
                    style={[
                      styles.filterOption,
                      tempFilters.verificationStatus === option.value && styles.filterOptionSelected
                    ]}
                    onPress={() => setTempFilters(prev => ({ ...prev, verificationStatus: option.value }))}
                  >
                    <Text style={[
                      styles.filterOptionText,
                      tempFilters.verificationStatus === option.value && styles.filterOptionTextSelected
                    ]}>
                      {option.label}
                    </Text>
                    {tempFilters.verificationStatus === option.value && (
                      <CheckCircle size={16} color={Colors.primary[500]} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>

          <View style={styles.filterActions}>
            <TouchableOpacity
              style={styles.clearFiltersButton}
              onPress={() => setTempFilters({
                medicationType: [],
                distance: 'all',
                expiryDate: 'all',
                verificationStatus: 'all',
                nearbyPharmacy: []
              })}
            >
              <Text style={styles.clearFiltersText}>Clear All</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.applyFiltersButton}
              onPress={() => applyFilters(tempFilters)}
            >
              <Text style={styles.applyFiltersText}>Apply Filters</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    );
  };

  const hasActiveFilters = filters.medicationType.length > 0 || filters.distance !== 'all' || 
    filters.expiryDate !== 'all' || filters.verificationStatus !== 'all' || filters.nearbyPharmacy.length > 0;

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Available Medicines</Text>
      </View>
      
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color={Colors.neutral[400]} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by name, type, or pharmacy..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity 
          style={[
            styles.filterButton,
            hasActiveFilters && styles.filterButtonActive
          ]}
          onPress={() => setShowFilterModal(true)}
        >
          <Filter size={20} color={hasActiveFilters ? Colors.white : Colors.neutral[600]} />
          {hasActiveFilters && <View style={styles.filterBadge} />}
        </TouchableOpacity>
      </View>

      {/* Results Header */}
      <View style={styles.resultsHeader}>
        <Text style={styles.resultsCount}>
          {filteredMedicines.length} medications found
        </Text>
        {hasActiveFilters && (
          <TouchableOpacity style={styles.clearFiltersHeaderButton} onPress={clearFilters}>
            <Text style={styles.clearFiltersHeaderText}>Clear filters</Text>
          </TouchableOpacity>
        )}
      </View>
      
      <FlatList
        data={filteredMedicines}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <MedicineCard 
            medicine={item} 
            onRequest={handleMedicineRequest}
          />
        )}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No medicines found</Text>
            <Text style={styles.emptySubtext}>
              Try adjusting your search criteria or filters
            </Text>
          </View>
        }
      />

      {/* Request Submitted Popup */}
      <Modal
        visible={showRequestPopup}
        transparent={true}
        animationType="fade"
        onRequestClose={closeRequestPopup}
      >
        <View style={styles.popupOverlay}>
          <Animated.View 
            style={styles.popupContainer}
            entering={FadeInDown.delay(100).springify()}
            exiting={FadeOutUp.springify()}
          >
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={closeRequestPopup}
            >
              <X size={20} color={Colors.neutral[500]} />
            </TouchableOpacity>
            
            <View style={styles.popupContent}>
              <View style={styles.successIcon}>
                <CheckCircle size={48} color={Colors.success[500]} />
              </View>
              
              <Text style={styles.popupTitle}>Request Submitted!</Text>
              
              <TouchableOpacity 
                style={styles.okButton}
                onPress={closeRequestPopup}
              >
                <Text style={styles.okButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Modal>

      <FilterModal />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    paddingHorizontal: Layout.spacing.md,
    paddingTop: Layout.spacing.md,
    paddingBottom: Layout.spacing.md,
    backgroundColor: Colors.white,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.neutral[100],
    borderRadius: Layout.borderRadius.md,
    paddingHorizontal: Layout.spacing.sm,
    marginRight: Layout.spacing.sm,
  },
  searchIcon: {
    marginRight: Layout.spacing.xs,
  },
  searchInput: {
    flex: 1,
    paddingVertical: Layout.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
  },
  filterButton: {
    width: 46,
    height: 46,
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  filterButtonActive: {
    backgroundColor: Colors.primary[500],
  },
  filterBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.accent[500],
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.sm,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  resultsCount: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[700],
  },
  clearFiltersHeaderButton: {
    paddingVertical: Layout.spacing.xs,
  },
  clearFiltersHeaderText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[600],
  },
  listContent: {
    padding: Layout.spacing.md,
    paddingBottom: 100,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Layout.spacing.xxl,
  },
  emptyText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[400],
  },
  emptySubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[400],
    marginTop: Layout.spacing.xs,
    textAlign: 'center',
  },
  // Popup Styles
  popupOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
  },
  popupContainer: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.xl,
    width: '100%',
    maxWidth: 320,
    position: 'relative',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 8,
  },
  closeButton: {
    position: 'absolute',
    top: Layout.spacing.md,
    right: Layout.spacing.md,
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  popupContent: {
    padding: Layout.spacing.xl,
    alignItems: 'center',
  },
  successIcon: {
    marginBottom: Layout.spacing.lg,
  },
  popupTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xl,
    textAlign: 'center',
  },
  okButton: {
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.sm,
    paddingHorizontal: Layout.spacing.xl,
    borderRadius: Layout.borderRadius.lg,
    minWidth: 100,
  },
  okButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
    textAlign: 'center',
  },
  // Filter Modal Styles
  filterModalContainer: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  filterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  filterTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  filterContent: {
    flex: 1,
    padding: Layout.spacing.lg,
  },
  filterSection: {
    marginBottom: Layout.spacing.xl,
  },
  filterSectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.md,
  },
  filterOptions: {
    gap: Layout.spacing.sm,
  },
  filterOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
  },
  filterOptionSelected: {
    borderColor: Colors.primary[500],
    backgroundColor: Colors.primary[50],
  },
  filterOptionText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[700],
  },
  filterOptionTextSelected: {
    color: Colors.primary[700],
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Layout.spacing.sm,
  },
  typeFilterOption: {
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.full,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
  },
  typeFilterOptionSelected: {
    backgroundColor: Colors.primary[500],
    borderColor: Colors.primary[500],
  },
  typeFilterText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[700],
  },
  typeFilterTextSelected: {
    color: Colors.white,
  },
  // Pharmacy Filter Styles
  pharmacyGrid: {
    gap: Layout.spacing.sm,
  },
  pharmacyFilterOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
  },
  pharmacyFilterOptionSelected: {
    backgroundColor: Colors.primary[500],
    borderColor: Colors.primary[500],
  },
  pharmacyFilterContent: {
    flex: 1,
  },
  pharmacyFilterName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: 4,
  },
  pharmacyFilterNameSelected: {
    color: Colors.white,
  },
  pharmacyFilterDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  pharmacyFilterDistance: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    marginLeft: 4,
  },
  pharmacyFilterDistanceSelected: {
    color: Colors.white,
  },
  filterActions: {
    flexDirection: 'row',
    gap: Layout.spacing.md,
    padding: Layout.spacing.lg,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  clearFiltersButton: {
    flex: 1,
    backgroundColor: Colors.neutral[200],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    alignItems: 'center',
  },
  clearFiltersText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[600],
  },
  applyFiltersButton: {
    flex: 2,
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    alignItems: 'center',
  },
  applyFiltersText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
});