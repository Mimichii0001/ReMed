import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  ScrollView,
  Linking 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Settings, LogOut, CreditCard as Edit2, ChevronRight, MapPin, Clock, Package, Star, ExternalLink, Award } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import DonationRating from '@/components/DonationRating';
import AccountSettings from '../../components/AccountSettings';

interface CompletedDonation {
  id: string;
  medicationName: string;
  strength: string;
  quantity: string;
  pharmacyName: string;
  status: 'verified' | 'delivered';
  donatedDate: string;
  verifiedBy?: string;
  rating?: number;
  hasRated: boolean;
}

const MOCK_COMPLETED_DONATIONS: CompletedDonation[] = [
  {
    id: '1',
    medicationName: 'Amoxicillin',
    strength: '500mg',
    quantity: '30 tablets',
    pharmacyName: 'MedCare Pharmacy',
    status: 'delivered',
    donatedDate: '3 days ago',
    verifiedBy: 'Dr. Michael C.',
    hasRated: false,
  },
];

export default function ProfileScreen() {
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [selectedDonation, setSelectedDonation] = useState<CompletedDonation | null>(null);
  const [completedDonations, setCompletedDonations] = useState(MOCK_COMPLETED_DONATIONS);
  const [showAccountSettings, setShowAccountSettings] = useState(false);

  const handleRateExperience = (donation: CompletedDonation) => {
    setSelectedDonation(donation);
    setShowRatingModal(true);
  };

  const handleRatingSubmit = (rating: number, comment: string) => {
    if (selectedDonation) {
      setCompletedDonations(prev =>
        prev.map(donation =>
          donation.id === selectedDonation.id
            ? { ...donation, rating, hasRated: true }
            : donation
        )
      );
    }
  };

  const renderStars = (rating: number) => {
    return (
      <View style={styles.starsContainer}>
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={14}
            color={star <= rating ? Colors.warning[500] : Colors.neutral[300]}
            fill={star <= rating ? Colors.warning[500] : 'transparent'}
          />
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.headerActions}>
            <TouchableOpacity onPress={() => setShowAccountSettings(true)}>
              <Settings size={24} color={Colors.neutral[700]} />
            </TouchableOpacity>
            <TouchableOpacity>
              <LogOut size={24} color={Colors.neutral[700]} />
            </TouchableOpacity>
          </View>
          
          <Animated.View 
            style={styles.profileSection}
            entering={FadeInDown.delay(100).springify()}
          >
            <Image
              source={{ uri: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" }}
              style={styles.profileImage}
            />
            <View style={styles.profileImageEditButton}>
              <Edit2 size={16} color={Colors.white} />
            </View>
            <Text style={styles.userName}>Sarah Johnson</Text>
            <Text style={styles.userLocation}>
              <MapPin size={14} color={Colors.neutral[500]} style={{ marginRight: 4 }} />
              San Francisco, CA
            </Text>
            <View style={styles.userStats}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>12</Text>
                <Text style={styles.statLabel}>Donations</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>8</Text>
                <Text style={styles.statLabel}>Verified</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>4</Text>
                <Text style={styles.statLabel}>Pending</Text>
              </View>
            </View>

            {/* Single Achievement Badge */}
            <View style={styles.achievementBadge}>
              <Award size={16} color={Colors.white} />
              <Text style={styles.achievementText}>Community Helper</Text>
            </View>
          </Animated.View>
        </View>

        <Animated.View 
          style={styles.sectionContainer}
          entering={FadeInDown.delay(200).springify()}
        >
          <Text style={styles.sectionTitle}>My Donations</Text>
          <View style={styles.donationCards}>
            {/* Completed Donations - Simplified */}
            {completedDonations.map((donation) => (
              <TouchableOpacity 
                key={donation.id}
                style={styles.donationCard}
                onPress={() => handleRateExperience(donation)}
              >
                <View style={[
                  styles.donationStatusBadge, 
                  { backgroundColor: donation.status === 'delivered' ? Colors.success[500] : Colors.primary[500] }
                ]}>
                  <Text style={styles.donationStatusText}>
                    {donation.status.toUpperCase()}
                  </Text>
                </View>
                <View style={styles.donationCardContent}>
                  <View style={styles.donationCardHeader}>
                    <Text style={styles.donationCardTitle}>
                      {donation.medicationName}
                    </Text>
                    <Text style={styles.donationCardDate}>
                      <Clock size={14} color={Colors.neutral[400]} style={{ marginRight: 2 }} />
                      Donated {donation.donatedDate}
                    </Text>
                  </View>
                  
                  {/* Rating Section */}
                  <View style={styles.ratingSection}>
                    {donation.hasRated ? (
                      <View style={styles.ratedContainer}>
                        <Text style={styles.ratedLabel}>Your rating:</Text>
                        {renderStars(donation.rating || 0)}
                        <Text style={styles.editRatingText}>Tap to edit</Text>
                      </View>
                    ) : (
                      <View style={styles.unratedContainer}>
                        <Star size={16} color={Colors.warning[500]} />
                        <Text style={styles.ratePromptText}>Rate this donation experience</Text>
                        <ChevronRight size={16} color={Colors.primary[500]} />
                      </View>
                    )}
                  </View>

                  <View style={styles.donationCardFooter}>
                    <Text style={styles.verifiedText}>
                      Verified by {donation.verifiedBy}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
            
            {/* Pending Donation - Simplified */}
            <TouchableOpacity style={styles.donationCard}>
              <View style={[styles.donationStatusBadge, { backgroundColor: Colors.warning[500] }]}>
                <Text style={styles.donationStatusText}>PENDING</Text>
              </View>
              <View style={styles.donationCardContent}>
                <View style={styles.donationCardHeader}>
                  <Text style={styles.donationCardTitle}>Metformin</Text>
                  <Text style={styles.donationCardDate}>
                    <Clock size={14} color={Colors.neutral[400]} style={{ marginRight: 2 }} />
                    Donated 1 day ago
                  </Text>
                </View>
                <View style={styles.donationCardFooter}>
                  <Text style={styles.pendingText}>
                    Awaiting pharmacist verification
                  </Text>
                  <ChevronRight size={20} color={Colors.neutral[400]} />
                </View>
              </View>
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity style={styles.viewAllButton}>
            <Text style={styles.viewAllButtonText}>View All Donations</Text>
            <ChevronRight size={16} color={Colors.primary[500]} />
          </TouchableOpacity>
        </Animated.View>

        <View style={styles.spacer} />
      </ScrollView>

      {selectedDonation && (
        <DonationRating
          visible={showRatingModal}
          onClose={() => {
            setShowRatingModal(false);
            setSelectedDonation(null);
          }}
          donationId={selectedDonation.id}
          medicationName={`${selectedDonation.medicationName} ${selectedDonation.strength}`}
          pharmacyName={selectedDonation.pharmacyName}
          onSubmitRating={handleRatingSubmit}
        />
      )}

      <AccountSettings
        visible={showAccountSettings}
        onClose={() => setShowAccountSettings(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    backgroundColor: Colors.white,
    padding: Layout.spacing.md,
    paddingBottom: Layout.spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  headerActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Layout.spacing.lg,
  },
  profileSection: {
    alignItems: 'center',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: Layout.spacing.md,
  },
  profileImageEditButton: {
    position: 'absolute',
    right: '35%',
    top: 70,
    backgroundColor: Colors.primary[500],
    borderRadius: Layout.borderRadius.full,
    width: 28,
    height: 28,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  userName: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  userLocation: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  userStats: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    paddingVertical: Layout.spacing.md,
    marginBottom: Layout.spacing.md,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 36,
    backgroundColor: Colors.neutral[200],
    marginHorizontal: Layout.spacing.xl,
  },
  // Single Achievement Badge
  achievementBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Layout.spacing.md,
    paddingVertical: Layout.spacing.xs,
    borderRadius: Layout.borderRadius.full,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  achievementText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.white,
    marginLeft: Layout.spacing.xs,
  },
  sectionContainer: {
    padding: Layout.spacing.md,
    marginTop: Layout.spacing.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.md,
  },
  donationCards: {
    gap: Layout.spacing.md,
    marginBottom: Layout.spacing.md,
  },
  donationCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  donationStatusBadge: {
    height: 4,
    width: '100%',
  },
  donationStatusText: {
    display: 'none',
  },
  donationCardContent: {
    padding: Layout.spacing.md,
  },
  donationCardHeader: {
    marginBottom: Layout.spacing.sm,
  },
  donationCardTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  donationCardDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[400],
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingSection: {
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.sm,
    marginBottom: Layout.spacing.sm,
  },
  ratedContainer: {
    alignItems: 'center',
    gap: 4,
  },
  ratedLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.neutral[600],
  },
  starsContainer: {
    flexDirection: 'row',
    gap: 2,
  },
  editRatingText: {
    fontFamily: 'Inter-Regular',
    fontSize: 11,
    color: Colors.primary[600],
  },
  unratedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Layout.spacing.xs,
  },
  ratePromptText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[600],
    flex: 1,
  },
  donationCardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Layout.spacing.xs,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  verifiedText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.success[600],
  },
  pendingText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.warning[600],
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Layout.spacing.sm,
  },
  viewAllButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.primary[500],
    marginRight: 4,
  },
  spacer: {
    height: 100,
  },
});