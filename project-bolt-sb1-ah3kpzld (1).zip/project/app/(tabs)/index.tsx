import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Bell, ArrowRight, TrendingUp, Shield, Award, Heart, Users, TriangleAlert as AlertTriangle, X, Plus, Search, Recycle, UserCheck } from 'lucide-react-native';
import StatsCard from '@/components/StatsCard';
import FeaturedDonation from '@/components/FeaturedDonation';
import NotificationCenter from '@/components/NotificationCenter';
import NotificationSettings from '@/components/NotificationSettings';
import ExpirationAlerts from '@/components/ExpirationAlerts';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';

interface ImpactCard {
  id: string;
  title: string;
  value: string;
  subtitle: string;
  icon: React.ReactNode;
  color: string;
  backgroundColor: string;
}

const IMPACT_CARDS: ImpactCard[] = [
  {
    id: 'donations',
    title: 'Donations',
    value: '12',
    subtitle: 'This month',
    icon: <TrendingUp size={20} color={Colors.primary[500]} />,
    color: Colors.primary[500],
    backgroundColor: Colors.primary[50],
  },
  {
    id: 'verified',
    title: 'Verified',
    value: '8',
    subtitle: 'By pharmacists',
    icon: <Shield size={20} color={Colors.secondary[500]} />,
    color: Colors.secondary[500],
    backgroundColor: Colors.secondary[50],
  },
  {
    id: 'lives_helped',
    title: 'Lives Helped',
    value: '24',
    subtitle: 'Estimated impact',
    icon: <Heart size={20} color={Colors.accent[500]} />,
    color: Colors.accent[500],
    backgroundColor: Colors.accent[50],
  },
  {
    id: 'community',
    title: 'Community',
    value: '156',
    subtitle: 'Active donors',
    icon: <Users size={20} color={Colors.success[500]} />,
    color: Colors.success[500],
    backgroundColor: Colors.success[50],
  },
];

export default function HomeScreen() {
  const router = useRouter();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showNotificationSettings, setShowNotificationSettings] = useState(false);
  const [showExpirationAlerts, setShowExpirationAlerts] = useState(false);
  const [showFirstTimePopup, setShowFirstTimePopup] = useState(false);

  useEffect(() => {
    // Check if this is the first time opening the app
    // In a real app, you'd check AsyncStorage or similar
    const isFirstTime = true; // This would be determined by checking stored data
    if (isFirstTime) {
      setShowFirstTimePopup(true);
    }
  }, []);

  const handleGetStarted = () => {
    setShowFirstTimePopup(false);
    // In a real app, you'd save that the user has seen the popup
  };

  const handleDonateAction = () => {
    setShowFirstTimePopup(false);
    router.push('/(tabs)/donate');
  };

  const handleFindAction = () => {
    setShowFirstTimePopup(false);
    router.push('/(tabs)/available');
  };

  const handleRecyclingPress = () => {
    router.push('/medication-recycling');
  };

  const renderImpactCard = (card: ImpactCard) => (
    <View key={card.id} style={[styles.impactCard, { backgroundColor: card.backgroundColor }]}>
      <View style={styles.impactCardIcon}>
        {card.icon}
      </View>
      <View style={styles.impactCardContent}>
        <Text style={styles.impactCardValue}>{card.value}</Text>
        <Text style={styles.impactCardTitle}>{card.title}</Text>
        <Text style={styles.impactCardSubtitle}>{card.subtitle}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.greeting}>Welcome back,</Text>
              <Text style={styles.username}>Sarah</Text>
            </View>
            <View style={styles.headerActions}>
              <TouchableOpacity 
                style={styles.notificationButton}
                onPress={() => setShowNotifications(true)}
              >
                <Bell size={24} color={Colors.neutral[700]} />
                <View style={styles.notificationBadge}>
                  <Text style={styles.notificationCount}>2</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        {/* Urgent Notifications Banner */}
        <View style={styles.urgentBanner}>
          <View style={styles.urgentContent}>
            <View style={styles.urgentIcon}>
              <Bell size={16} color={Colors.warning[600]} />
            </View>
            <View style={styles.urgentText}>
              <Text style={styles.urgentTitle}>Medication Ready!</Text>
            </View>
            <TouchableOpacity 
              style={styles.urgentAction}
              onPress={() => setShowNotifications(true)}
            >
              <ArrowRight size={14} color={Colors.warning[600]} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Expiration Alert Banner */}
        <View style={styles.expirationBanner}>
          <View style={styles.expirationContent}>
            <View style={styles.expirationIcon}>
              <AlertTriangle size={16} color={Colors.error[600]} />
            </View>
            <View style={styles.expirationText}>
              <Text style={styles.expirationTitle}>Expiration Alert</Text>
            </View>
            <TouchableOpacity 
              style={styles.expirationAction}
              onPress={() => setShowExpirationAlerts(true)}
            >
              <ArrowRight size={14} color={Colors.error[600]} />
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Impact Section - Horizontal Cards */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Impact</Text>
          </View>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.impactCardsContainer}
            style={styles.impactCardsScroll}
          >
            {IMPACT_CARDS.map(renderImpactCard)}
          </ScrollView>
        </View>

        {/* Verification Process Section */}
        <View style={styles.section}>
          <View style={styles.verificationCard}>
            <View style={styles.verificationIconContainer}>
              <View style={styles.pharmacistIconBackground}>
                <UserCheck size={48} color={Colors.primary[500]} />
              </View>
              <View style={styles.verificationOverlay}>
                <View style={styles.verificationBadge}>
                  <Award size={14} color={Colors.white} />
                  <Text style={styles.verificationBadgeText}>VERIFIED PROCESS</Text>
                </View>
              </View>
            </View>
            <View style={styles.verificationContent}>
              <Text style={styles.verificationTitle}>Pharmacist Verification</Text>
              <TouchableOpacity 
                style={styles.learnMoreButton}
                onPress={() => router.push('/verification-process')}
              >
                <Text style={styles.learnMoreText}>Learn more about our process</Text>
                <ArrowRight size={16} color={Colors.white} />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Featured Donations Section - Made Smaller */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View>
              <Text style={styles.sectionTitle}>Featured Donations</Text>
            </View>
            <TouchableOpacity style={styles.seeAllButton}>
              <Text style={styles.seeAllText}>See all</Text>
              <ArrowRight size={16} color={Colors.primary[500]} />
            </TouchableOpacity>
          </View>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.featuredScrollContent}
            style={styles.featuredScroll}
          >
            <FeaturedDonation 
              name="Amoxicillin"
              type="Antibiotic"
              distance="2.3 miles away"
              expiryDate="Jan 2025"
              imageUrl="https://images.pexels.com/photos/139398/himalayas-mountains-nepal-hill-139398.jpeg?auto=compress&cs=tinysrgb&w=800"
            />
            <FeaturedDonation 
              name="Metformin"
              type="Diabetes"
              distance="0.8 miles away"
              expiryDate="Dec 2024"
              imageUrl="https://images.pexels.com/photos/208512/pexels-photo-208512.jpeg?auto=compress&cs=tinysrgb&w=800"
            />
          </ScrollView>
        </View>

        {/* Medication Recycling Section */}
        <View style={styles.section}>
          <TouchableOpacity 
            style={styles.comingSoonCard}
            onPress={handleRecyclingPress}
          >
            <View style={styles.comingSoonHeader}>
              <View style={styles.comingSoonIcon}>
                <Recycle size={32} color={Colors.accent[600]} />
              </View>
              <View style={styles.comingSoonContent}>
                <Text style={styles.comingSoonTitle}>Medication Recycling</Text>
                <Text style={styles.comingSoonSubtitle}>(Coming Soon)</Text>
              </View>
              <ArrowRight size={20} color={Colors.accent[600]} />
            </View>
          </TouchableOpacity>
        </View>

        {/* Bottom Spacer */}
        <View style={styles.bottomSpacer} />
      </ScrollView>

      {/* First Time User Popup */}
      <Modal
        visible={showFirstTimePopup}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowFirstTimePopup(false)}
      >
        <View style={styles.popupOverlay}>
          <Animated.View 
            style={styles.popupContainer}
            entering={FadeInDown.delay(100).springify()}
          >
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowFirstTimePopup(false)}
            >
              <X size={20} color={Colors.neutral[500]} />
            </TouchableOpacity>
            
            <View style={styles.popupContent}>
              <Animated.View 
                style={styles.welcomeIcon}
                entering={FadeInUp.delay(200).springify()}
              >
                <Heart size={48} color={Colors.primary[500]} />
              </Animated.View>
              
              <Text style={styles.popupTitle}>Welcome to ReMed!</Text>
              
              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={styles.donateButton}
                  onPress={handleDonateAction}
                >
                  <Plus size={16} color={Colors.white} />
                  <Text style={styles.donateButtonText}>Donate Medicine</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={styles.findButton}
                  onPress={handleFindAction}
                >
                  <Search size={16} color={Colors.primary[600]} />
                  <Text style={styles.findButtonText}>Find Medicine</Text>
                </TouchableOpacity>
              </View>
              
              <TouchableOpacity 
                style={styles.skipButton}
                onPress={handleGetStarted}
              >
                <Text style={styles.skipButtonText}>I'll explore on my own</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Modal>

      {/* Notification Components */}
      <NotificationCenter 
        visible={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
      
      <NotificationSettings
        visible={showNotificationSettings}
        onClose={() => setShowNotificationSettings(false)}
      />

      <ExpirationAlerts
        visible={showExpirationAlerts}
        onClose={() => setShowExpirationAlerts(false)}
        userRole="donor"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    backgroundColor: Colors.white,
    paddingBottom: Layout.spacing.lg,
    borderBottomLeftRadius: Layout.borderRadius.xl,
    borderBottomRightRadius: Layout.borderRadius.xl,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingTop: Layout.spacing.md,
  },
  greeting: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[500],
    marginBottom: 2,
  },
  username: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Layout.spacing.sm,
  },
  notificationButton: {
    width: 48,
    height: 48,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  notificationBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: Colors.accent[500],
    width: 18,
    height: 18,
    borderRadius: Layout.borderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  notificationCount: {
    fontFamily: 'Inter-Bold',
    fontSize: 10,
    color: Colors.white,
  },
  urgentBanner: {
    marginHorizontal: Layout.spacing.lg,
    marginTop: Layout.spacing.md,
    backgroundColor: Colors.warning[50],
    borderRadius: Layout.borderRadius.md,
    borderWidth: 1,
    borderColor: Colors.warning[200],
    overflow: 'hidden',
  },
  urgentContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Layout.spacing.sm,
  },
  urgentIcon: {
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.warning[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.sm,
  },
  urgentText: {
    flex: 1,
  },
  urgentTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.warning[800],
  },
  urgentAction: {
    width: 28,
    height: 28,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.warning[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  expirationBanner: {
    marginHorizontal: Layout.spacing.lg,
    marginTop: Layout.spacing.sm,
    backgroundColor: Colors.error[50],
    borderRadius: Layout.borderRadius.md,
    borderWidth: 1,
    borderColor: Colors.error[200],
    overflow: 'hidden',
  },
  expirationContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Layout.spacing.sm,
  },
  expirationIcon: {
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.error[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.sm,
  },
  expirationText: {
    flex: 1,
  },
  expirationTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.error[800],
  },
  expirationAction: {
    width: 28,
    height: 28,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.error[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  section: {
    marginTop: Layout.spacing.xl,
    paddingHorizontal: Layout.spacing.lg,
  },
  sectionHeader: {
    marginBottom: Layout.spacing.lg,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 22,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  // Impact Cards - Horizontal Scroll
  impactCardsScroll: {
    marginHorizontal: -Layout.spacing.lg,
  },
  impactCardsContainer: {
    paddingHorizontal: Layout.spacing.lg,
    gap: Layout.spacing.md,
  },
  impactCard: {
    width: 140,
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  impactCardIcon: {
    marginBottom: Layout.spacing.sm,
  },
  impactCardContent: {
    alignItems: 'flex-start',
  },
  impactCardValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  impactCardTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[600],
    marginBottom: 2,
  },
  impactCardSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[500],
  },
  verificationCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.xl,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 3,
  },
  verificationIconContainer: {
    position: 'relative',
    height: 180,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  pharmacistIconBackground: {
    width: 120,
    height: 120,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  verificationOverlay: {
    position: 'absolute',
    top: Layout.spacing.md,
    left: Layout.spacing.md,
  },
  verificationBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(20, 184, 166, 0.9)',
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: Layout.spacing.xs,
    borderRadius: Layout.borderRadius.full,
    backdropFilter: 'blur(10px)',
  },
  verificationBadgeText: {
    fontFamily: 'Inter-Bold',
    fontSize: 11,
    color: Colors.white,
    marginLeft: 4,
    letterSpacing: 0.5,
  },
  verificationContent: {
    padding: Layout.spacing.lg,
  },
  verificationTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.lg,
  },
  learnMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.lg,
  },
  learnMoreText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 15,
    color: Colors.white,
    marginRight: Layout.spacing.xs,
  },
  seeAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Layout.spacing.xs,
  },
  seeAllText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 15,
    color: Colors.primary[500],
    marginRight: 4,
  },
  featuredScroll: {
    marginHorizontal: -Layout.spacing.lg,
  },
  featuredScrollContent: {
    paddingHorizontal: Layout.spacing.lg,
    paddingRight: Layout.spacing.xl,
  },
  comingSoonCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.xl,
    padding: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 2,
    borderColor: Colors.accent[100],
  },
  comingSoonHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  comingSoonIcon: {
    width: 60,
    height: 60,
    borderRadius: Layout.borderRadius.lg,
    backgroundColor: Colors.accent[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.md,
  },
  comingSoonContent: {
    flex: 1,
  },
  comingSoonTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  comingSoonSubtitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.accent[600],
  },
  bottomSpacer: {
    height: Layout.spacing.xxl + Layout.spacing.lg,
  },
  // First Time Popup Styles
  popupOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
  },
  popupContainer: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.xl,
    width: '100%',
    maxWidth: 360,
    position: 'relative',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 8,
  },
  closeButton: {
    position: 'absolute',
    top: Layout.spacing.md,
    right: Layout.spacing.md,
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  popupContent: {
    padding: Layout.spacing.xl,
    alignItems: 'center',
  },
  welcomeIcon: {
    width: 80,
    height: 80,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.lg,
  },
  popupTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xl,
    textAlign: 'center',
  },
  actionButtons: {
    width: '100%',
    gap: Layout.spacing.md,
    marginBottom: Layout.spacing.lg,
  },
  donateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  donateButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  findButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[50],
    borderWidth: 2,
    borderColor: Colors.primary[200],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  findButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.primary[600],
  },
  skipButton: {
    paddingVertical: Layout.spacing.sm,
  },
  skipButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[500],
    textDecorationLine: 'underline',
  },
});