import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Image,
  Modal,
  Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { Camera, Calendar, Pill, Image as ImageIcon, Heart, TriangleAlert as AlertTriangle, MapPin, Star, Phone, Navigation, X, CircleCheck as CheckCircle } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import DonationSubmitted from '@/components/screens/DonationSubmitted';

interface Pharmacy {
  id: string;
  name: string;
  address: string;
  distance: string;
  phone: string;
  hours: string;
  rating: number;
  reviewCount: number;
  imageUrl: string;
  logoUrl: string;
  verified: boolean;
  specialties: string[];
}

const MOCK_PHARMACIES: Pharmacy[] = [
  {
    id: '1',
    name: 'MedCare Pharmacy',
    address: '123 Main St, San Francisco, CA 94102',
    distance: '0.3 miles',
    phone: '(415) 555-0123',
    hours: 'Open until 9:00 PM',
    rating: 4.8,
    reviewCount: 127,
    imageUrl: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['Prescription Filling', 'Medication Counseling', 'Immunizations']
  },
  {
    id: '2',
    name: 'Community Health Pharmacy',
    address: '456 Oak Ave, San Francisco, CA 94103',
    distance: '0.7 miles',
    phone: '(415) 555-0456',
    hours: 'Open until 8:00 PM',
    rating: 4.6,
    reviewCount: 89,
    imageUrl: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['Compounding', 'Diabetes Care', 'Blood Pressure Monitoring']
  },
  {
    id: '3',
    name: 'Wellness Pharmacy Plus',
    address: '789 Pine St, San Francisco, CA 94108',
    distance: '1.2 miles',
    phone: '(415) 555-0789',
    hours: 'Open until 10:00 PM',
    rating: 4.9,
    reviewCount: 203,
    imageUrl: 'https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoUrl: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=100',
    verified: true,
    specialties: ['24/7 Service', 'Emergency Prescriptions', 'Home Delivery']
  },
];

// Restricted medication patterns and keywords
const RESTRICTED_MEDICATIONS = {
  narcotics: [
    'morphine', 'oxycodone', 'hydrocodone', 'codeine', 'fentanyl', 'tramadol',
    'oxycontin', 'percocet', 'vicodin', 'norco', 'dilaudid', 'demerol',
    'methadone', 'suboxone', 'buprenorphine', 'opium', 'heroin'
  ],
  controlledSubstances: [
    'adderall', 'ritalin', 'concerta', 'vyvanse', 'dextroamphetamine',
    'methylphenidate', 'amphetamine', 'xanax', 'alprazolam', 'lorazepam',
    'ativan', 'clonazepam', 'klonopin', 'diazepam', 'valium', 'ambien',
    'zolpidem', 'lunesta', 'eszopiclone', 'temazepam', 'restoril'
  ],
  personalUse: [
    'birth control', 'contraceptive', 'fertility', 'clomid', 'letrozole',
    'antidepressant', 'prozac', 'zoloft', 'lexapro', 'wellbutrin', 'cymbalta',
    'psychiatric', 'antipsychotic', 'lithium', 'seroquel', 'abilify',
    'hormonal', 'testosterone', 'estrogen', 'progesterone', 'thyroid',
    'levothyroxine', 'synthroid', 'insulin', 'diabetic'
  ],
  invalidTerms: [
    'expired', 'no expiration', 'unknown expiry', 'loose pills', 'no packaging',
    'opened bottle', 'partial bottle', 'leftover', 'old medication'
  ]
};

export default function DonateScreen() {
  const router = useRouter();
  const [submitted, setSubmitted] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedPharmacy, setSelectedPharmacy] = useState<Pharmacy | null>(null);
  const [showPharmacyModal, setShowPharmacyModal] = useState(false);
  const [showGuidelinesPopup, setShowGuidelinesPopup] = useState(false);
  const [formData, setFormData] = useState({
    medicineName: '',
    expiryDate: '',
    quantity: '',
    description: '',
  });
  const [expiryError, setExpiryError] = useState('');
  const [medicineNameError, setMedicineNameError] = useState('');

  const validateMedicineName = (name: string) => {
    if (!name.trim()) {
      setMedicineNameError('');
      return true;
    }

    const lowerName = name.toLowerCase().trim();
    
    // Check for narcotics and controlled substances
    const isNarcotic = RESTRICTED_MEDICATIONS.narcotics.some(drug => 
      lowerName.includes(drug)
    );
    
    const isControlled = RESTRICTED_MEDICATIONS.controlledSubstances.some(drug => 
      lowerName.includes(drug)
    );
    
    const isPersonalUse = RESTRICTED_MEDICATIONS.personalUse.some(drug => 
      lowerName.includes(drug)
    );
    
    const hasInvalidTerms = RESTRICTED_MEDICATIONS.invalidTerms.some(term => 
      lowerName.includes(term)
    );

    if (isNarcotic || isControlled) {
      setMedicineNameError('We cannot accept narcotics or controlled substances for safety and legal reasons.');
      return false;
    }

    if (isPersonalUse) {
      setMedicineNameError('We cannot accept personal-use medications like fertility, psychiatric, or hormonal drugs.');
      return false;
    }

    if (hasInvalidTerms) {
      setMedicineNameError('Please ensure medications are unexpired and in original packaging with clear labeling.');
      return false;
    }

    // Additional pattern checks
    if (lowerName.includes('schedule') || lowerName.includes('controlled')) {
      setMedicineNameError('We cannot accept controlled substances for safety and legal reasons.');
      return false;
    }

    setMedicineNameError('');
    return true;
  };

  const validateExpiryDate = (dateString: string) => {
    if (!dateString) {
      setExpiryError('');
      return true;
    }

    // Parse MM/YYYY format
    const parts = dateString.split('/');
    if (parts.length !== 2) {
      setExpiryError('Please use MM/YYYY format');
      return false;
    }

    const month = parseInt(parts[0], 10);
    const year = parseInt(parts[1], 10);

    if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
      setExpiryError('Please enter a valid date');
      return false;
    }

    // Create expiry date (last day of the month)
    const expiryDate = new Date(year, month, 0);
    const today = new Date();
    const sixMonthsFromNow = new Date();
    sixMonthsFromNow.setMonth(today.getMonth() + 6);

    if (expiryDate <= today) {
      setExpiryError('Medication has already expired');
      return false;
    }

    if (expiryDate < sixMonthsFromNow) {
      setExpiryError('Sorry we can\'t accept medication that expire in less than 6 months for safety reasons');
      return false;
    }

    setExpiryError('');
    return true;
  };

  const handleMedicineNameChange = (text: string) => {
    setFormData({...formData, medicineName: text});
    validateMedicineName(text);
  };

  const handleExpiryDateChange = (text: string) => {
    // Auto-format MM/YYYY
    let formattedText = text.replace(/\D/g, ''); // Remove non-digits
    if (formattedText.length >= 2) {
      formattedText = formattedText.substring(0, 2) + '/' + formattedText.substring(2, 6);
    }
    
    setFormData({...formData, expiryDate: formattedText});
    validateExpiryDate(formattedText);
  };

  const handleNextStep = () => {
    // Validate step 1 fields
    if (!formData.medicineName.trim()) {
      setMedicineNameError('Medicine name is required');
      return;
    }
    
    if (!validateMedicineName(formData.medicineName)) {
      return;
    }
    
    if (!formData.expiryDate.trim()) {
      setExpiryError('Expiry date is required');
      return;
    }
    
    if (!formData.quantity.trim()) {
      return;
    }

    // Validate expiry date
    if (!validateExpiryDate(formData.expiryDate)) {
      return;
    }

    setCurrentStep(2);
  };

  const handleSubmit = () => {
    if (!selectedPharmacy) {
      return;
    }

    // Final validation before submission
    if (!validateMedicineName(formData.medicineName)) {
      Alert.alert(
        'Invalid Medication',
        'Please review the medication name. We cannot accept the medication you\'ve entered.',
        [{ text: 'OK' }]
      );
      setCurrentStep(1);
      return;
    }

    // Submit the donation
    setSubmitted(true);
  };

  const handlePharmacySelect = (pharmacy: Pharmacy) => {
    setSelectedPharmacy(pharmacy);
    setShowPharmacyModal(false);
  };

  const renderPharmacyCard = (pharmacy: Pharmacy) => (
    <TouchableOpacity 
      key={pharmacy.id}
      style={[
        styles.pharmacyCard,
        selectedPharmacy?.id === pharmacy.id && styles.pharmacyCardSelected
      ]}
      onPress={() => handlePharmacySelect(pharmacy)}
    >
      <View style={styles.pharmacyContent}>
        <View style={styles.pharmacyHeader}>
          <View style={styles.pharmacyNameContainer}>
            <Image
              source={{ uri: pharmacy.logoUrl }}
              style={styles.pharmacyLogo}
            />
            <Text style={styles.pharmacyName}>{pharmacy.name}</Text>
          </View>
          <View style={styles.ratingContainer}>
            <Star size={12} color={Colors.warning[500]} fill={Colors.warning[500]} />
            <Text style={styles.rating}>{pharmacy.rating}</Text>
          </View>
        </View>
        
        <View style={styles.pharmacyDetails}>
          <View style={styles.detailRow}>
            <Navigation size={12} color={Colors.primary[500]} />
            <Text style={styles.detailText}>{pharmacy.distance}</Text>
          </View>
          <View style={styles.detailRow}>
            <MapPin size={12} color={Colors.neutral[500]} />
            <Text style={styles.detailText}>{pharmacy.address}</Text>
          </View>
        </View>
        
        <View style={styles.pharmacyActions}>
          <TouchableOpacity 
            style={styles.selectButton}
            onPress={() => handlePharmacySelect(pharmacy)}
          >
            <CheckCircle size={14} color={Colors.white} />
            <Text style={styles.selectButtonText}>Select</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.directionsButton}>
            <Navigation size={14} color={Colors.primary[600]} />
            <Text style={styles.directionsButtonText}>Directions</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  const PharmacySelectionModal = () => (
    <Modal
      visible={showPharmacyModal}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <SafeAreaView style={styles.modalContainer} edges={['top', 'right', 'left', 'bottom']}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>Select Pharmacy</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setShowPharmacyModal(false)}
          >
            <X size={24} color={Colors.neutral[600]} />
          </TouchableOpacity>
        </View>
        
        <ScrollView style={styles.modalContent}>
          <Text style={styles.modalSubtitle}>
            Choose a verified pharmacy near you to handle your donation
          </Text>
          
          <View style={styles.pharmacyList}>
            {MOCK_PHARMACIES.map(renderPharmacyCard)}
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );

  const GuidelinesPopup = () => (
    <Modal
      visible={showGuidelinesPopup}
      transparent={true}
      animationType="fade"
      onRequestClose={() => setShowGuidelinesPopup(false)}
    >
      <View style={styles.popupOverlay}>
        <View style={styles.guidelinesPopup}>
          <View style={styles.guidelinesHeader}>
            <View style={styles.guidelinesIconContainer}>
              <AlertTriangle size={24} color={Colors.warning[600]} />
            </View>
            <Text style={styles.guidelinesTitle}>Donation Guidelines</Text>
            <TouchableOpacity
              style={styles.popupCloseButton}
              onPress={() => setShowGuidelinesPopup(false)}
            >
              <X size={20} color={Colors.neutral[500]} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.guidelinesContent}>
            <Text style={styles.guidelinesDescription}>
              We cannot accept:
            </Text>
            <View style={styles.guidelinesList}>
              <Text style={styles.guidelinesItem}>• Narcotics or controlled substances</Text>
              <Text style={styles.guidelinesItem}>• Expired medications or those without clear expiration dates</Text>
              <Text style={styles.guidelinesItem}>• Personal-use drugs (fertility, psychiatric, hormonal)</Text>
              <Text style={styles.guidelinesItem}>• Items without original packaging or patient leaflets</Text>
            </View>
            
            <TouchableOpacity
              style={styles.understoodButton}
              onPress={() => setShowGuidelinesPopup(false)}
            >
              <Text style={styles.understoodButtonText}>I Understand</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  if (submitted) {
    return <DonationSubmitted />;
  }

  const isStep1Valid = formData.medicineName.trim() && 
                      formData.expiryDate.trim() && 
                      formData.quantity.trim() && 
                      !expiryError && 
                      !medicineNameError;

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left', 'top']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Progress Indicator */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View style={[styles.progressStep, currentStep >= 1 && styles.progressStepActive]}>
                <Text style={[styles.progressStepText, currentStep >= 1 && styles.progressStepTextActive]}>1</Text>
              </View>
              <View style={[styles.progressLine, currentStep >= 2 && styles.progressLineActive]} />
              <View style={[styles.progressStep, currentStep >= 2 && styles.progressStepActive]}>
                <Text style={[styles.progressStepText, currentStep >= 2 && styles.progressStepTextActive]}>2</Text>
              </View>
            </View>
            <View style={styles.progressLabels}>
              <Text style={styles.progressLabel}>Medication Details</Text>
              <Text style={styles.progressLabel}>Select Pharmacy</Text>
            </View>
          </View>

          {currentStep === 1 ? (
            <>
              <View style={styles.titleContainer}>
                <Text style={styles.title}>Donate Medicine</Text>
                <TouchableOpacity
                  style={styles.warningIconButton}
                  onPress={() => setShowGuidelinesPopup(true)}
                >
                  <AlertTriangle size={20} color={Colors.warning[600]} />
                </TouchableOpacity>
              </View>
              <Text style={styles.subtitle}>
                Please provide accurate information about your medication
              </Text>
              
              <View style={styles.formContainer}>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Medicine Name *</Text>
                  <View style={[
                    styles.inputContainer,
                    medicineNameError ? styles.inputContainerError : null
                  ]}>
                    <Pill size={20} color={Colors.primary[400]} style={styles.inputIcon} />
                    <TextInput
                      style={styles.input}
                      placeholder="Enter medicine name"
                      value={formData.medicineName}
                      onChangeText={handleMedicineNameChange}
                    />
                  </View>
                  {medicineNameError ? (
                    <View style={styles.errorContainer}>
                      <AlertTriangle size={16} color={Colors.error[500]} />
                      <Text style={styles.errorText}>{medicineNameError}</Text>
                    </View>
                  ) : null}
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Expiry Date *</Text>
                  <View style={[
                    styles.inputContainer,
                    expiryError ? styles.inputContainerError : null
                  ]}>
                    <Calendar size={20} color={Colors.primary[400]} style={styles.inputIcon} />
                    <TextInput
                      style={styles.input}
                      placeholder="MM/YYYY"
                      value={formData.expiryDate}
                      onChangeText={handleExpiryDateChange}
                      keyboardType="numeric"
                      maxLength={7}
                    />
                  </View>
                  {expiryError ? (
                    <View style={styles.errorContainer}>
                      <AlertTriangle size={16} color={Colors.error[500]} />
                      <Text style={styles.errorText}>{expiryError}</Text>
                    </View>
                  ) : null}
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Quantity *</Text>
                  <View style={styles.inputContainer}>
                    <TextInput
                      style={styles.input}
                      placeholder="Number of units/tablets"
                      value={formData.quantity}
                      onChangeText={(text) => setFormData({...formData, quantity: text})}
                      keyboardType="number-pad"
                    />
                  </View>
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Description</Text>
                  <View style={[styles.inputContainer, styles.textAreaContainer]}>
                    <TextInput
                      style={[styles.input, styles.textArea]}
                      placeholder="Additional details about the medicine's condition, packaging, etc."
                      value={formData.description}
                      onChangeText={(text) => setFormData({...formData, description: text})}
                      multiline
                      numberOfLines={4}
                      textAlignVertical="top"
                    />
                  </View>
                </View>

                <View style={styles.imageUploadContainer}>
                  <Text style={styles.label}>Upload Photos (Optional)</Text>
                  <TouchableOpacity style={styles.imageUploadButton}>
                    <View style={styles.imageUploadContent}>
                      <View style={styles.imageIconContainer}>
                        <ImageIcon size={24} color={Colors.primary[500]} />
                      </View>
                      <Text style={styles.imageUploadText}>Tap to add photos</Text>
                    </View>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity
                  style={[
                    styles.nextButton,
                    !isStep1Valid ? styles.nextButtonDisabled : null
                  ]}
                  onPress={handleNextStep}
                  activeOpacity={0.8}
                  disabled={!isStep1Valid}
                >
                  <Text style={[
                    styles.nextButtonText,
                    !isStep1Valid ? styles.nextButtonTextDisabled : null
                  ]}>
                    Next: Select Pharmacy
                  </Text>
                </TouchableOpacity>
              </View>
            </>
          ) : (
            <>
              <Text style={styles.title}>Select Pharmacy</Text>
              <Text style={styles.subtitle}>
                Choose a verified pharmacy to handle your donation
              </Text>

              {selectedPharmacy ? (
                <View style={styles.selectedPharmacyContainer}>
                  <Text style={styles.selectedPharmacyLabel}>Selected Pharmacy:</Text>
                  {renderPharmacyCard(selectedPharmacy)}
                  <TouchableOpacity 
                    style={styles.changePharmacyButton}
                    onPress={() => setShowPharmacyModal(true)}
                  >
                    <Text style={styles.changePharmacyText}>Change Pharmacy</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <View style={styles.pharmacySelectionContainer}>
                  <TouchableOpacity 
                    style={styles.selectPharmacyButton}
                    onPress={() => setShowPharmacyModal(true)}
                  >
                    <MapPin size={20} color={Colors.primary[500]} />
                    <Text style={styles.selectPharmacyText}>Select Pharmacy</Text>
                  </TouchableOpacity>
                </View>
              )}

              <View style={styles.impactSection}>
                <View style={styles.impactHeader}>
                  <Heart size={20} color={Colors.accent[500]} />
                  <Text style={styles.impactTitle}>Why Donation Matters</Text>
                </View>
                
                <Text style={styles.impactDescription}>
                  Your donation helps someone access treatment they otherwise couldn't afford.
                </Text>
              </View>

              <View style={styles.stepActions}>
                <TouchableOpacity
                  style={styles.backButton}
                  onPress={() => setCurrentStep(1)}
                >
                  <Text style={styles.backButtonText}>Back</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.submitButton,
                    !selectedPharmacy ? styles.submitButtonDisabled : null
                  ]}
                  onPress={handleSubmit}
                  activeOpacity={0.8}
                  disabled={!selectedPharmacy}
                >
                  <Text style={[
                    styles.submitButtonText,
                    !selectedPharmacy ? styles.submitButtonTextDisabled : null
                  ]}>
                    Submit Donation
                  </Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>

      <PharmacySelectionModal />
      <GuidelinesPopup />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  scrollContainer: {
    paddingHorizontal: Layout.spacing.md,
    paddingTop: Layout.spacing.md,
    paddingBottom: Layout.spacing.xxl,
  },
  progressContainer: {
    marginBottom: Layout.spacing.xl,
  },
  progressBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.sm,
  },
  progressStep: {
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[200],
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressStepActive: {
    backgroundColor: Colors.primary[500],
  },
  progressStepText: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: Colors.neutral[500],
  },
  progressStepTextActive: {
    color: Colors.white,
  },
  progressLine: {
    width: 60,
    height: 2,
    backgroundColor: Colors.neutral[200],
    marginHorizontal: Layout.spacing.sm,
  },
  progressLineActive: {
    backgroundColor: Colors.primary[500],
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: Layout.spacing.lg,
  },
  progressLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.neutral[500],
    textAlign: 'center',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Layout.spacing.xs,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    flex: 1,
  },
  warningIconButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.warning[50],
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.warning[200],
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[500],
    marginBottom: Layout.spacing.xl,
    lineHeight: 22,
  },
  formContainer: {
    gap: Layout.spacing.lg,
  },
  inputGroup: {
    gap: Layout.spacing.xs,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[700],
    marginBottom: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.spacing.sm,
  },
  inputContainerError: {
    borderColor: Colors.error[500],
    borderWidth: 2,
  },
  inputIcon: {
    marginRight: Layout.spacing.xs,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
    paddingVertical: Platform.OS === 'ios' ? 12 : 8,
  },
  textAreaContainer: {
    minHeight: 120,
    alignItems: 'flex-start',
  },
  textArea: {
    paddingTop: Layout.spacing.sm,
    height: 100,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Layout.spacing.xs,
    gap: Layout.spacing.xs,
  },
  errorText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.error[500],
    flex: 1,
  },
  imageUploadContainer: {
    marginTop: Layout.spacing.sm,
  },
  imageUploadButton: {
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderStyle: 'dashed',
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.neutral[50],
  },
  imageUploadContent: {
    alignItems: 'center',
    gap: Layout.spacing.xs,
  },
  imageIconContainer: {
    width: 48,
    height: 48,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.xs,
  },
  imageUploadText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.primary[600],
  },
  nextButton: {
    backgroundColor: Colors.primary[500],
    borderRadius: Layout.borderRadius.md,
    paddingVertical: Layout.spacing.md,
    alignItems: 'center',
    marginTop: Layout.spacing.lg,
  },
  nextButtonDisabled: {
    backgroundColor: Colors.neutral[200],
  },
  nextButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
  nextButtonTextDisabled: {
    color: Colors.neutral[400],
  },
  // Step 2 Styles
  selectedPharmacyContainer: {
    marginBottom: Layout.spacing.xl,
  },
  selectedPharmacyLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: Colors.neutral[700],
    marginBottom: Layout.spacing.md,
  },
  changePharmacyButton: {
    alignSelf: 'center',
    marginTop: Layout.spacing.md,
    paddingVertical: Layout.spacing.sm,
  },
  changePharmacyText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.primary[600],
    textDecorationLine: 'underline',
  },
  pharmacySelectionContainer: {
    alignItems: 'center',
    marginBottom: Layout.spacing.xl,
  },
  selectPharmacyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary[50],
    borderWidth: 2,
    borderColor: Colors.primary[200],
    borderStyle: 'dashed',
    paddingVertical: Layout.spacing.lg,
    paddingHorizontal: Layout.spacing.xl,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.sm,
    marginBottom: Layout.spacing.md,
  },
  selectPharmacyText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.primary[600],
  },
  impactSection: {
    backgroundColor: Colors.accent[25],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.md,
    marginBottom: Layout.spacing.xl,
    borderWidth: 1,
    borderColor: Colors.accent[100],
  },
  impactHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.sm,
  },
  impactTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.accent[800],
    marginLeft: Layout.spacing.sm,
  },
  impactDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.accent[700],
    lineHeight: 20,
  },
  stepActions: {
    flexDirection: 'row',
    gap: Layout.spacing.md,
  },
  backButton: {
    flex: 1,
    backgroundColor: Colors.neutral[200],
    borderRadius: Layout.borderRadius.md,
    paddingVertical: Layout.spacing.md,
    alignItems: 'center',
  },
  backButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[600],
  },
  submitButton: {
    flex: 2,
    backgroundColor: Colors.primary[500],
    borderRadius: Layout.borderRadius.md,
    paddingVertical: Layout.spacing.md,
    alignItems: 'center',
  },
  submitButtonDisabled: {
    backgroundColor: Colors.neutral[200],
  },
  submitButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
  submitButtonTextDisabled: {
    color: Colors.neutral[400],
  },
  // Pharmacy Card Styles
  pharmacyCard: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.lg,
    overflow: 'hidden',
    marginBottom: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 2,
    borderColor: Colors.transparent,
  },
  pharmacyCardSelected: {
    borderColor: Colors.primary[500],
    backgroundColor: Colors.primary[25],
  },
  pharmacyContent: {
    padding: Layout.spacing.lg,
  },
  pharmacyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Layout.spacing.md,
  },
  pharmacyNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: Layout.spacing.sm,
  },
  pharmacyLogo: {
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.md,
    marginRight: Layout.spacing.sm,
    backgroundColor: Colors.neutral[100],
  },
  pharmacyName: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    flex: 1,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.neutral[800],
    marginLeft: 4,
  },
  pharmacyDetails: {
    marginBottom: Layout.spacing.md,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.sm,
  },
  detailText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    marginLeft: 4,
    flex: 1,
  },
  pharmacyActions: {
    flexDirection: 'row',
    gap: Layout.spacing.md,
  },
  selectButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    gap: Layout.spacing.xs,
  },
  selectButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  directionsButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[50],
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    gap: Layout.spacing.xs,
  },
  directionsButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.primary[600],
  },
  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  modalTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalContent: {
    flex: 1,
    padding: Layout.spacing.lg,
  },
  modalSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[600],
    marginBottom: Layout.spacing.xl,
    textAlign: 'center',
  },
  pharmacyList: {
    gap: Layout.spacing.md,
  },
  // Guidelines Popup Styles
  popupOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
  },
  guidelinesPopup: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.xl,
    width: '100%',
    maxWidth: 400,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 8,
  },
  guidelinesHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Layout.spacing.lg,
    paddingTop: Layout.spacing.lg,
    paddingBottom: Layout.spacing.md,
  },
  guidelinesIconContainer: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.warning[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.sm,
  },
  guidelinesTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    flex: 1,
  },
  popupCloseButton: {
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  guidelinesContent: {
    paddingHorizontal: Layout.spacing.lg,
    paddingBottom: Layout.spacing.lg,
  },
  guidelinesDescription: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.neutral[700],
    marginBottom: Layout.spacing.md,
  },
  guidelinesList: {
    gap: Layout.spacing.sm,
    marginBottom: Layout.spacing.xl,
  },
  guidelinesItem: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
  },
  understoodButton: {
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    alignItems: 'center',
  },
  understoodButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
});