import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { ArrowLeft, Shield, Award, CircleCheck as CheckCircle, Clock, Users, Eye } from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';

export default function VerificationProcessScreen() {
  const router = useRouter();

  const verificationSteps = [
    {
      icon: <Eye size={24} color={Colors.primary[500]} />,
      title: 'Initial Review',
      description: 'Licensed pharmacists examine medication packaging, expiry dates, and condition to ensure safety standards.',
      duration: '2-4 hours',
    },
    {
      icon: <Shield size={24} color={Colors.secondary[500]} />,
      title: 'Safety Verification',
      description: 'Comprehensive checks for tampering, proper storage conditions, and medication integrity.',
      duration: '4-8 hours',
    },
    {
      icon: <CheckCircle size={24} color={Colors.success[500]} />,
      title: 'Final Approval',
      description: 'Final quality assurance and documentation before making the medication available for redistribution.',
      duration: '1-2 hours',
    },
  ];

  const safetyMeasures = [
    'Temperature-controlled storage verification',
    'Tamper-evident packaging inspection',
    'Expiry date validation (minimum 6 months remaining)',
    'Prescription authenticity verification',
    'Chain of custody documentation',
    'Quality assurance protocols',
  ];

  return (
    <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <Animated.View 
          style={styles.header}
          entering={FadeInUp.delay(100).springify()}
        >
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color={Colors.neutral[700]} />
          </TouchableOpacity>
        </Animated.View>

        {/* Process Overview */}
        <Animated.View 
          style={styles.section}
          entering={FadeInDown.delay(300).springify()}
        >
          <Text style={styles.sectionTitle}>Our Verification Process</Text>
          <Text style={styles.sectionDescription}>
            Every medication donation goes through a rigorous 3-step verification process to ensure safety and quality before redistribution.
          </Text>
          
          <View style={styles.processContainer}>
            {verificationSteps.map((step, index) => (
              <Animated.View 
                key={index}
                style={styles.processStep}
                entering={FadeInDown.delay(400 + index * 100).springify()}
              >
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>{index + 1}</Text>
                </View>
                
                <View style={styles.stepContent}>
                  <View style={styles.stepHeader}>
                    <View style={styles.stepIcon}>
                      {step.icon}
                    </View>
                    <View style={styles.stepTitleContainer}>
                      <Text style={styles.stepTitle}>{step.title}</Text>
                      <View style={styles.durationBadge}>
                        <Clock size={12} color={Colors.neutral[500]} />
                        <Text style={styles.durationText}>{step.duration}</Text>
                      </View>
                    </View>
                  </View>
                  <Text style={styles.stepDescription}>{step.description}</Text>
                </View>
                
                {index < verificationSteps.length - 1 && (
                  <View style={styles.stepConnector} />
                )}
              </Animated.View>
            ))}
          </View>
        </Animated.View>

        {/* Safety Measures */}
        <Animated.View 
          style={styles.section}
          entering={FadeInDown.delay(600).springify()}
        >
          <Text style={styles.sectionTitle}>Safety Measures</Text>
          <Text style={styles.sectionDescription}>
            Our comprehensive safety protocols ensure that only the highest quality medications reach those in need.
          </Text>
          
          <View style={styles.safetyContainer}>
            {safetyMeasures.map((measure, index) => (
              <Animated.View 
                key={index}
                style={styles.safetyItem}
                entering={FadeInDown.delay(700 + index * 50).springify()}
              >
                <CheckCircle size={20} color={Colors.success[500]} />
                <Text style={styles.safetyText}>{measure}</Text>
              </Animated.View>
            ))}
          </View>
        </Animated.View>

        {/* Statistics */}
        <Animated.View 
          style={styles.statsSection}
          entering={FadeInDown.delay(800).springify()}
        >
          <Text style={styles.sectionTitle}>Trust & Reliability</Text>
          
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Shield size={24} color={Colors.primary[500]} />
              </View>
              <Text style={styles.statValue}>99.8%</Text>
              <Text style={styles.statLabel}>Safety Rate</Text>
            </View>
            
            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Users size={24} color={Colors.secondary[500]} />
              </View>
              <Text style={styles.statValue}>500+</Text>
              <Text style={styles.statLabel}>Licensed Pharmacists</Text>
            </View>
            
            <View style={styles.statCard}>
              <View style={styles.statIcon}>
                <Award size={24} color={Colors.accent[500]} />
              </View>
              <Text style={styles.statValue}>24-48h</Text>
              <Text style={styles.statLabel}>Average Review Time</Text>
            </View>
          </View>
        </Animated.View>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  section: {
    padding: Layout.spacing.lg,
    backgroundColor: Colors.white,
    marginTop: Layout.spacing.lg,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.sm,
  },
  sectionDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[600],
    lineHeight: 24,
    marginBottom: Layout.spacing.xl,
  },
  processContainer: {
    gap: Layout.spacing.lg,
  },
  processStep: {
    position: 'relative',
  },
  stepNumber: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  stepNumberText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
  stepContent: {
    marginLeft: 48,
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: Layout.spacing.sm,
  },
  stepIcon: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.lg,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.sm,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  stepTitleContainer: {
    flex: 1,
  },
  stepTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  durationBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.spacing.sm,
    paddingVertical: 4,
    borderRadius: Layout.borderRadius.full,
    alignSelf: 'flex-start',
    gap: 4,
  },
  durationText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: Colors.neutral[600],
  },
  stepDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    color: Colors.neutral[600],
    lineHeight: 22,
  },
  stepConnector: {
    position: 'absolute',
    left: 15,
    top: 32,
    bottom: -Layout.spacing.lg,
    width: 2,
    backgroundColor: Colors.primary[200],
  },
  safetyContainer: {
    gap: Layout.spacing.md,
  },
  safetyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.success[25],
    padding: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.success[100],
    gap: Layout.spacing.sm,
  },
  safetyText: {
    fontFamily: 'Inter-Medium',
    fontSize: 15,
    color: Colors.success[800],
    flex: 1,
  },
  statsSection: {
    padding: Layout.spacing.lg,
    backgroundColor: Colors.white,
    marginTop: Layout.spacing.lg,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: Layout.spacing.md,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    alignItems: 'center',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: Layout.borderRadius.lg,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.sm,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.neutral[800],
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: Colors.neutral[500],
    textAlign: 'center',
  },
  bottomSpacer: {
    height: Layout.spacing.xxl,
  },
});