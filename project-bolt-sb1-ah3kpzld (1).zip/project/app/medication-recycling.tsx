import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import Colors from '@/constants/Colors';
import Layout from '@/constants/Layout';
import { ArrowLeft, Recycle, Droplets, Fish, Shield, MapPin, Calendar, Package, ExternalLink, CircleCheck as CheckCircle, TriangleAlert as AlertTriangle } from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';

interface DropOffForm {
  medicationName: string;
  quantity: string;
  expiryDate: string;
  location: string;
  contactInfo: string;
  additionalNotes: string;
}

export default function MedicationRecyclingScreen() {
  const router = useRouter();
  const [formData, setFormData] = useState<DropOffForm>({
    medicationName: '',
    quantity: '',
    expiryDate: '',
    location: '',
    contactInfo: '',
    additionalNotes: '',
  });
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitForm = () => {
    if (!formData.medicationName.trim() || !formData.contactInfo.trim()) {
      Alert.alert('Required Fields', 'Please fill in medication name and contact information.');
      return;
    }

    setSubmitted(true);
    Alert.alert(
      'Request Submitted!',
      'Thank you for your interest in medication recycling. We\'ll contact you when certified drop-off centers become available in your area.',
      [
        {
          text: 'OK',
          onPress: () => {
            setFormData({
              medicationName: '',
              quantity: '',
              expiryDate: '',
              location: '',
              contactInfo: '',
              additionalNotes: '',
            });
            setShowForm(false);
            setSubmitted(false);
          },
        },
      ]
    );
  };

  const handleLearnMore = async () => {
    const url = 'https://www.fda.gov/consumers/consumer-updates/where-and-how-dispose-unused-medicines';
    try {
      const supported = await Linking.canOpenURL(url);
      if (supported) {
        await Linking.openURL(url);
      }
    } catch (error) {
      console.error('Error opening URL:', error);
    }
  };

  const impactStats = [
    {
      icon: <Droplets size={24} color={Colors.primary[500]} />,
      title: 'Water Protection',
      description: 'Prevents pharmaceutical contamination of water supplies',
      stat: '80%',
      statLabel: 'of water systems affected by improper disposal',
    },
    {
      icon: <Fish size={24} color={Colors.secondary[500]} />,
      title: 'Wildlife Safety',
      description: 'Protects aquatic life from harmful drug residues',
      stat: '200+',
      statLabel: 'species affected by pharmaceutical pollution',
    },
    {
      icon: <Shield size={24} color={Colors.success[500]} />,
      title: 'Community Safety',
      description: 'Reduces accidental poisoning and drug misuse',
      stat: '60K',
      statLabel: 'children visit ER annually from accidental ingestion',
    },
  ];

  const recyclingSteps = [
    {
      step: 1,
      title: 'Check for Take-Back Programs',
      description: 'Look for DEA-authorized collection sites in your area',
    },
    {
      step: 2,
      title: 'Remove Personal Information',
      description: 'Scratch out all personal details on prescription labels',
    },
    {
      step: 3,
      title: 'Keep Original Container',
      description: 'Leave medications in their original packaging when possible',
    },
    {
      step: 4,
      title: 'Drop Off Safely',
      description: 'Bring to certified collection sites or pharmacy programs',
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={['top', 'right', 'left', 'bottom']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <Animated.View 
          style={styles.header}
          entering={FadeInUp.delay(100).springify()}
        >
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color={Colors.neutral[700]} />
          </TouchableOpacity>
          
          <View style={styles.headerContent}>
            <View style={styles.headerIcon}>
              <Recycle size={32} color={Colors.primary[500]} />
            </View>
            <Text style={styles.headerTitle}>Medication Recycling</Text>
            <Text style={styles.headerSubtitle}>Coming Soon</Text>
            <Text style={styles.headerDescription}>
              Protecting our environment and communities through safe medication disposal
            </Text>
          </View>
        </Animated.View>

        {/* Why It Matters Section */}
        <Animated.View 
          style={styles.section}
          entering={FadeInDown.delay(200).springify()}
        >
          <Text style={styles.sectionTitle}>Why Medication Recycling Matters</Text>
          <Text style={styles.sectionDescription}>
            Improper disposal of expired medications poses serious risks to our environment, wildlife, and communities. Here's how proper recycling makes a difference:
          </Text>
          
          <View style={styles.impactContainer}>
            {impactStats.map((impact, index) => (
              <Animated.View 
                key={index}
                style={styles.impactCard}
                entering={FadeInDown.delay(300 + index * 100).springify()}
              >
                <View style={styles.impactIcon}>
                  {impact.icon}
                </View>
                <View style={styles.impactContent}>
                  <Text style={styles.impactTitle}>{impact.title}</Text>
                  <Text style={styles.impactDescription}>{impact.description}</Text>
                  <View style={styles.impactStats}>
                    <Text style={styles.impactStat}>{impact.stat}</Text>
                  </View>
                </View>
              </Animated.View>
            ))}
          </View>
        </Animated.View>

        {/* How to Recycle Section */}
        <Animated.View 
          style={styles.section}
          entering={FadeInDown.delay(400).springify()}
        >
          <Text style={styles.sectionTitle}>How to Recycle Safely</Text>
          <Text style={styles.sectionDescription}>
            Follow these steps to ensure your expired medications are disposed of safely and responsibly:
          </Text>
          
          <View style={styles.stepsContainer}>
            {recyclingSteps.map((step, index) => (
              <Animated.View 
                key={index}
                style={styles.stepCard}
                entering={FadeInDown.delay(500 + index * 100).springify()}
              >
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>{step.step}</Text>
                </View>
                <View style={styles.stepContent}>
                  <Text style={styles.stepTitle}>{step.title}</Text>
                  <Text style={styles.stepDescription}>{step.description}</Text>
                </View>
              </Animated.View>
            ))}
          </View>
          
          <TouchableOpacity 
            style={styles.learnMoreButton}
            onPress={handleLearnMore}
          >
            <ExternalLink size={16} color={Colors.white} />
            <Text style={styles.learnMoreText}>Learn More from FDA</Text>
          </TouchableOpacity>
        </Animated.View>

        {/* Coming Soon Notice */}
        <Animated.View 
          style={styles.comingSoonSection}
          entering={FadeInDown.delay(600).springify()}
        >
          <View style={styles.comingSoonCard}>
            <View style={styles.comingSoonHeader}>
              <AlertTriangle size={24} color={Colors.warning[600]} />
              <Text style={styles.comingSoonTitle}>Service Coming Soon</Text>
            </View>
            <Text style={styles.comingSoonDescription}>
              We're working on partnering with certified medication disposal centers to make recycling easier for our community.
            </Text>
          </View>
        </Animated.View>

        {/* Report Form Section */}
        <Animated.View 
          style={styles.section}
          entering={FadeInDown.delay(700).springify()}
        >
          <Text style={styles.sectionTitle}>Report Expired Medications</Text>
          <Text style={styles.sectionDescription}>
            Help us understand the demand for recycling services in your area by reporting medications you'd like to dispose of safely.
          </Text>
          
          {!showForm ? (
            <TouchableOpacity 
              style={styles.showFormButton}
              onPress={() => setShowForm(true)}
            >
              <Package size={16} color={Colors.white} />
              <Text style={styles.showFormButtonText}>Report Medications</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.formContainer}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Medication Name *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., Amoxicillin, Ibuprofen"
                  value={formData.medicationName}
                  onChangeText={(text) => setFormData({...formData, medicationName: text})}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Quantity</Text>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., 30 tablets, 1 bottle"
                  value={formData.quantity}
                  onChangeText={(text) => setFormData({...formData, quantity: text})}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Expiry Date</Text>
                <TextInput
                  style={styles.input}
                  placeholder="MM/YYYY"
                  value={formData.expiryDate}
                  onChangeText={(text) => setFormData({...formData, expiryDate: text})}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Your Location</Text>
                <TextInput
                  style={styles.input}
                  placeholder="City, State"
                  value={formData.location}
                  onChangeText={(text) => setFormData({...formData, location: text})}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Contact Information *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Email or phone number"
                  value={formData.contactInfo}
                  onChangeText={(text) => setFormData({...formData, contactInfo: text})}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Additional Notes</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={formData.additionalNotes}
                  onChangeText={(text) => setFormData({...formData, additionalNotes: text})}
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                />
              </View>

              <View style={styles.formActions}>
                <TouchableOpacity 
                  style={styles.cancelButton}
                  onPress={() => setShowForm(false)}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[
                    styles.submitButton,
                    (!formData.medicationName.trim() || !formData.contactInfo.trim()) && styles.submitButtonDisabled
                  ]}
                  onPress={handleSubmitForm}
                  disabled={!formData.medicationName.trim() || !formData.contactInfo.trim()}
                >
                  <CheckCircle size={16} color={Colors.white} />
                  <Text style={styles.submitButtonText}>Submit Report</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </Animated.View>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.lg,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerIcon: {
    width: 80,
    height: 80,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Layout.spacing.md,
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 28,
    color: Colors.neutral[800],
    textAlign: 'center',
    marginBottom: Layout.spacing.xs,
  },
  headerSubtitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.primary[600],
    marginBottom: Layout.spacing.sm,
  },
  headerDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[600],
    textAlign: 'center',
    lineHeight: 24,
    maxWidth: 300,
  },
  section: {
    padding: Layout.spacing.lg,
    backgroundColor: Colors.white,
    marginTop: Layout.spacing.lg,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.sm,
  },
  sectionDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[600],
    lineHeight: 24,
    marginBottom: Layout.spacing.xl,
  },
  impactContainer: {
    gap: Layout.spacing.lg,
  },
  impactCard: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  impactIcon: {
    width: 56,
    height: 56,
    borderRadius: Layout.borderRadius.lg,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  impactContent: {
    flex: 1,
  },
  impactTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  impactDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
    marginBottom: Layout.spacing.sm,
  },
  impactStats: {
    backgroundColor: Colors.white,
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.sm,
  },
  impactStat: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.primary[600],
  },
  stepsContainer: {
    gap: Layout.spacing.md,
    marginBottom: Layout.spacing.xl,
  },
  stepCard: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    alignItems: 'flex-start',
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: Layout.borderRadius.full,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Layout.spacing.md,
  },
  stepNumberText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.white,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: Colors.neutral[800],
    marginBottom: Layout.spacing.xs,
  },
  stepDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: Colors.neutral[600],
    lineHeight: 20,
  },
  learnMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    paddingHorizontal: Layout.spacing.xl,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  learnMoreText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  comingSoonSection: {
    paddingHorizontal: Layout.spacing.lg,
    paddingVertical: Layout.spacing.lg,
  },
  comingSoonCard: {
    backgroundColor: Colors.warning[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    borderWidth: 1,
    borderColor: Colors.warning[200],
  },
  comingSoonHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Layout.spacing.md,
  },
  comingSoonTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: Colors.warning[800],
    marginLeft: Layout.spacing.sm,
  },
  comingSoonDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    color: Colors.warning[700],
    lineHeight: 22,
  },
  showFormButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.md,
    borderRadius: Layout.borderRadius.lg,
    gap: Layout.spacing.xs,
  },
  showFormButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  formContainer: {
    backgroundColor: Colors.neutral[50],
    borderRadius: Layout.borderRadius.lg,
    padding: Layout.spacing.lg,
    gap: Layout.spacing.md,
  },
  inputGroup: {
    gap: Layout.spacing.xs,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.neutral[700],
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    borderRadius: Layout.borderRadius.md,
    padding: Layout.spacing.sm,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.neutral[800],
    backgroundColor: Colors.white,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  formActions: {
    flexDirection: 'row',
    gap: Layout.spacing.md,
    marginTop: Layout.spacing.md,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    backgroundColor: Colors.neutral[200],
    alignItems: 'center',
  },
  cancelButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.neutral[600],
  },
  submitButton: {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary[500],
    paddingVertical: Layout.spacing.sm,
    borderRadius: Layout.borderRadius.md,
    gap: Layout.spacing.xs,
  },
  submitButtonDisabled: {
    backgroundColor: Colors.neutral[300],
  },
  submitButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  bottomSpacer: {
    height: Layout.spacing.xxl,
  },
});